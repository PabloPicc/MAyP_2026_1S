import requests

def obtener_texto():
    # REEMPLAZAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass

input("Presiona Enter para descargar el texto.")
texto = obtener_texto()
print("\nTexto recibido:")
print(texto)

