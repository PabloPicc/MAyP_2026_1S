# -----------------------------------------------------
# Este programa consulta la API pública "Advice Slip"
# y muestra por pantalla un consejo aleatorio.
# La API devuelve la respuesta en formato JSON.
# -----------------------------------------------------

import requests

def obtener_consejo():
    # REEMPLAZAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass

# Cuerpo principal del programa
input("Presioná Enter para obtener un consejo aleatorio.")
consejo = obtener_consejo()
print("\nConsejo recibido:")
print(consejo)

