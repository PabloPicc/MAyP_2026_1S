# -----------------------------------------------------
# Este programa consulta la API pública "Advice Slip"
# y muestra por pantalla un consejo aleatorio.
# La API devuelve la respuesta en formato JSON.
# -----------------------------------------------------

import requests

def obtener_consejo():
    url = "https://api.adviceslip.com/advice"

    # Realizamos la solicitud HTTP GET
    response = requests.get(url)

    # Convertimos la respuesta a diccionario Python
    data = response.json()

    # Devolvemos el consejo recibido
    return data["slip"]["advice"]

# Cuerpo principal del programa
input("Presioná Enter para obtener un consejo aleatorio.")
consejo = obtener_consejo()
print("\nConsejo recibido:")
print(consejo)

