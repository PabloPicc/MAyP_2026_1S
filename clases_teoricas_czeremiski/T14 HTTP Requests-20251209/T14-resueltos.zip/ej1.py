import requests

def obtener_texto():
    url = "https://www.learningcontainer.com/wp-content/uploads/2020/04/sample-text-file.txt"

    # Realizamos la solicitud HTTP GET
    response = requests.get(url)
    return response.text

input("Presiona Enter para descargar el texto.")
texto = obtener_texto()
print("\nTexto recibido:")
print(texto)

