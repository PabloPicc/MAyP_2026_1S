"""
Ejercicio 2 - Agrupamientos con pandas

Archivo CSV: estudiantes.csv

nombre,edad,carrera,promedio,correo
Norberto Catalá Adán,20,Economía,7.69,oangulo@hotmail.com
Leandro Lledó Escalona,29,Derecho,8.27,ghuerta@yahoo.com
Maxi Riquelme Guillen,18,Ingeniería,8.3,rosalindaabad@yahoo.com
Jesusa Figuerola Palomares,21,Medicina,8.93,nsalvador@hotmail.com
Agustín Polo,22,Medicina,6.51,piglesias@gmail.com
...
"""

import pandas as pd

# 1. Crear un DataFrame a partir del archivo CSV
df = pd.read_csv("estudiantes.csv")

# 2. Agrupar los datos por carrera y calcular el promedio de 'promedio'
### COMPLETAR ###

# 3. Agrupar por carrera y obtener múltiples funciones de agregación
# mean → promedio, min → valor mínimo, max → valor máximo
### COMPLETAR ###

# 4. Contar cuántos estudiantes hay en cada carrera
### COMPLETAR ###

# 5. Identificar qué carrera tiene el promedio más alto y cuál el más bajo
### COMPLETAR ###
