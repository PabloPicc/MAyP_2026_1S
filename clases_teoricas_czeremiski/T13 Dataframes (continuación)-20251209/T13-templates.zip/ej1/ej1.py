import pandas as pd

# 1. Cargar el CSV en un DataFrame
df = pd.read_csv("estudiantes.csv")

# 2. Mostrar las primeras 10 filas
print("=== Primeras 10 filas ===")
### COMPLETAR ###

# 3. Seleccionar estudiantes de Medicina
print("\n=== Estudiantes de Medicina ===")
### COMPLETAR ###

# 4. Seleccionar estudiantes con promedio mayor a 9
print("\n=== Estudiantes con promedio > 9 ===")
### COMPLETAR ###

# 5. Seleccionar estudiantes de Ingeniería con promedio menor a 7
print("\n=== Ingeniería con promedio < 7 ===")
### COMPLETAR ###

# 6. Estudiantes de Derecho o Economía con promedio > 9
print("\n=== Derecho o Economía con promedio > 9 ===")
### COMPLETAR ###

# 7. Estudiantes que no sean de Medicina
print("\n=== No Medicina ===")
### COMPLETAR ###

# 8. Ingeniería con promedio > 9, solo columnas nombre y promedio
print("\n=== Ingeniería con promedio > 9 (solo nombre y promedio) ===")
### COMPLETAR ###
