"""
Ejercicio 2 - Agrupamientos con pandas

Archivo CSV: estudiantes.csv

nombre,edad,carrera,promedio,correo
Norberto Catalá Adán,20,Economía,7.69,oangulo@hotmail.com
Leandro Lledó Escalona,29,Derecho,8.27,ghuerta@yahoo.com
Maxi Riquelme Guillen,18,Ingeniería,8.3,rosalindaabad@yahoo.com
Jesusa Figuerola Palomares,21,Medicina,8.93,nsalvador@hotmail.com
Agustín Polo,22,Medicina,6.51,piglesias@gmail.com
...
"""

import pandas as pd

# 1. Crear un DataFrame a partir del archivo CSV
df = pd.read_csv("estudiantes.csv")

# 2. Agrupar los datos por carrera y calcular el promedio de 'promedio'
promedios = df.groupby("carrera")["promedio"].mean()
print("Promedio de 'promedio' por carrera:")
print(promedios, "\n")

# 3. Agrupar por carrera y obtener múltiples funciones de agregación
# mean → promedio, min → valor mínimo, max → valor máximo
resumen = df.groupby("carrera")["promedio"].agg(["mean", "min", "max"])
print("Funciones de agregación (mean, min, max) por carrera:")
print(resumen, "\n")

# 4. Contar cuántos estudiantes hay en cada carrera
conteo = df.groupby("carrera").size()
print("Cantidad de estudiantes por carrera:")
print(conteo, "\n")

# 5. Identificar qué carrera tiene el promedio más alto y cuál el más bajo
print("Carrera con promedio más alto:")
promedios_ordenados = promedios.sort_values(ascending = False)
print(promedios_ordenados[0:1], "\n")
print("Carrera con promedio más bajo:")
print(promedios_ordenados[-1:], "\n")
