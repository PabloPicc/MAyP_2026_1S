"""
Solución al ejercicio de filtros con DataFrame.
"""

import pandas as pd

# 1. Cargar el CSV en un DataFrame
df = pd.read_csv("estudiantes.csv")

# 2. Mostrar las primeras 10 filas
print("=== Primeras 10 filas ===")
print(df.head(10))

# 3. Seleccionar estudiantes de Medicina
print("\n=== Estudiantes de Medicina ===")
medicina = df[df["carrera"] == "Medicina"]
print(medicina)

# 4. Seleccionar estudiantes con promedio mayor a 9
print("\n=== Estudiantes con promedio > 9 ===")
promedio_mayor_9 = df[df["promedio"] > 9]
print(promedio_mayor_9)

# 5. Seleccionar estudiantes de Ingeniería con promedio menor a 7
print("\n=== Ingeniería con promedio < 7 ===")
ing_menor_7 = df[(df["carrera"] == "Ingeniería") & (df["promedio"] < 7)]
print(ing_menor_7)

# 6. Estudiantes de Derecho o Economía con promedio > 9
print("\n=== Derecho o Economía con promedio > 9 ===")
der_ec_prom_9 = df[((df["carrera"] == "Derecho") | (df["carrera"] == "Economía")) & (df["promedio"] > 9)]
print(der_ec_prom_9)

# 7. Estudiantes que no sean de Medicina
print("\n=== No Medicina ===")
no_medicina = df[df["carrera"] != "Medicina"]
print(no_medicina)

# 8. Ingeniería con promedio > 9, solo columnas nombre y promedio
print("\n=== Ingeniería con promedio > 9 (solo nombre y promedio) ===")
ing_prom_9_cols = df[(df["carrera"] == "Ingeniería") & (df["promedio"] > 9)][["nombre", "promedio"]]
print(ing_prom_9_cols)

