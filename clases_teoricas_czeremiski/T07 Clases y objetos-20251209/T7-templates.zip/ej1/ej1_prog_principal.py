# Definir una función que dada una lista no vacía de automóviles devuelva la
# marca del automóvil más veloz.

# Se importa la clase Auto
from clase_automovil import Automovil

def marca_auto_mas_veloz(autos):
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass
        


# Programa principal para probar la función marca_auto_mas_veloz
auto1 = Automovil("Renault", "Sandero", 172)
auto2 = Automovil("Ford", "Fiesta", 190)
auto3 = Automovil("Volkswagen", "Surán", 167)
auto4 = Automovil("Fiat", "Punto", 181)

autos = [auto1, auto2, auto3, auto4]
# La siguiente línea debería imprimir "La marca del auto más veloz es Ford"
print("La marca del auto más veloz es " + marca_auto_mas_veloz(autos) + ".")
