class Cuadrado:
    
    def __init__(self, long_lado):
        # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
        pass
        
    def perimetro(self):
        # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
        pass
    
    def superficie(self):
        # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
        pass
    
    
