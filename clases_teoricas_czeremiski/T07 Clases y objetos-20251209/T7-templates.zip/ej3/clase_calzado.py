# Clase para representar calzados
class Calzado:

    # Constructor de objetos de tipo Calzado
    def __init__(self, mar, mod, pre):
        self.marca = mar
        self.modelo = mod
        self.precio = pre

