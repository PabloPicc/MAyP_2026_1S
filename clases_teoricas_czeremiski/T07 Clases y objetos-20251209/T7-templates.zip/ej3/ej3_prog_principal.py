from clase_calzado import Calzado
from clase_carrito_compras import CarritoDeCompras

calzado1 = Calzado("Puma", "Borussia", 8699.99)
calzado2 = Calzado("Adidas", "New York", 7800.00)

carrito = CarritoDeCompras()
carrito.agregar(calzado1)
carrito.agregar(calzado2)
print(carrito.monto_total())     # Imprime '16499.99'

carrito.eliminar(calzado2)
print(carrito.monto_total())     # Imprime '8699.99'
