from clase_calzado import Calzado

# Clase para representar carritos de compra
class CarritoDeCompras:

    # Constructor de objetos de tipo CarritoDeCompras
    def __init__(self):
        self.contenido = []

    # Agrega un calzado al carrito
    def agregar(self, calzado):
        self.contenido.append(calzado)

    # Elimina un calzado del carrito
    def eliminar(self, calzado):
        if calzado in self.contenido:
            self.contenido.remove(calzado)

    # Devuelve el precio total del contenido del carrito
    def monto_total(self):
        # [BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR]
        pass
