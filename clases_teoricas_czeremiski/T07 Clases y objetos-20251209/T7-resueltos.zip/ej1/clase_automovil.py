# Clase para representar automóviles
class Automovil:

    # Constructor de objetos de tipo Automovil
    def __init__(self, mar, mod, vel_max):
        self.marca = mar
        self.modelo = mod
        self.velocidad_maxima = vel_max

