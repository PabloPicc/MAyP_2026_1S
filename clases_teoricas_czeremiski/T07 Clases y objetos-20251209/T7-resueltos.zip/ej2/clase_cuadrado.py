# Clase para representar cuadrados
class Cuadrado:

    # Constructor de objetos de tipo cuadrados
    def __init__(self, long_lado):
        self.lado = long_lado

    # Devuelve el perímetro del cuadrado
    def perimetro(self):
        return self.lado * 4

    # Devuelve la superficie del cuadrdo
    def superficie(self):
        return self.lado * self.lado
