from clase_cuadrado import Cuadrado

# Cuerpo del programa principal
c1 = Cuadrado(5.0)
print('Lado de c1: ' + str(c1.lado)) 	      # 5.0
print('Per. de c1: ' + str(c1.perimetro()))   # 20.0
print('Sup. de c1: ' + str(c1.superficie()))  # 25.0

c2 = Cuadrado(2.0)
print('Lado de c2: ' + str(c2.lado)) 	      # 2.0
print('Per. de c2: ' + str(c2.perimetro()))   # 8.0
print('Sup. de c2: ' + str(c2.superficie()))  # 4.0

