# ============================================================
# Este programa consulta la API pública de Open-Meteo para
# obtener la temperatura actual en una ubicación especificada
# por el usuario.
# ============================================================

import requests

# --------------------------------------------------------------------
# Función para solicitar parámetros al usuario
# --------------------------------------------------------------------
def solicitar_parametros():
    """Pide al usuario las coordenadas geográficas."""
    latitud = input("Ingrese la latitud: ")
    longitud = input("Ingrese la longitud: ")
    return (latitud, longitud)


# --------------------------------------------------------------------
# Función para consultar la API de Open-Meteo y devolver 
# la temperatura actual en el lugar indicado.
# --------------------------------------------------------------------
def obtener_temperatura_actual(lat, lon):
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


# --------------------------------------------------------------------
# Cuerpo principal del programa
# --------------------------------------------------------------------
# Solicitar latitud y longitud
ubicacion = solicitar_parametros()
lat = ubicacion[0]
lon = ubicacion[1]
temperatura = obtener_temperatura_actual(lat, lon)
print('Temperatura: ', temperatura)


