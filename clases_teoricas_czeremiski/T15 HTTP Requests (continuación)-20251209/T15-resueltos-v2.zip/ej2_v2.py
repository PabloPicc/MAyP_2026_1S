# ============================================================
# Este programa consulta la API pública de Open-Meteo para
# obtener datos históricos de temperatura en una ubicación
# y período indicados por el usuario.
# Devuelve la temperatura máxima registrada en ese intervalo.
# ============================================================

import requests

# --------------------------------------------------------------------
# Función para solicitar parámetros al usuario
# --------------------------------------------------------------------
def solicitar_parametros():
    latitud = input("Ingrese la latitud: ")
    longitud = input("Ingrese la longitud: ")
    inicio = input("Ingrese la fecha de inicio (YYYY-MM-DD): ")
    fin = input("Ingrese la fecha de fin (YYYY-MM-DD): ")
    return (latitud, longitud, inicio, fin)

# --------------------------------------------------------------------
# Función para consultar la API de Open-Meteo y devuelve la lista 
# de temperaturas para el punto y el período indicado.
# --------------------------------------------------------------------
def obtener_temperaturas(lat, lon, start, end):
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass

# --------------------------------------------------------------------
# Cuerpo principal del programa
# --------------------------------------------------------------------
params_usuario = solicitar_parametros()
lat = params_usuario[0]
lon = params_usuario[1]
start = params_usuario[2]
end = params_usuario[3]

temperaturas = obtener_temperaturas(lat, lon, start, end)
temp_max = max(temperaturas)
print("La temperatura máxima registrada entre las fechas indicadas fue de:")
print(temp_max, "°C")


