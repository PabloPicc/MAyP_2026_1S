# ============================================================
# Este programa consulta la API pública de Open-Meteo para
# obtener la temperatura actual en una ubicación especificada
# por el usuario.
# ============================================================

import requests

# --------------------------------------------------------------------
# Función para solicitar parámetros al usuario
# --------------------------------------------------------------------
def solicitar_parametros():
    """Pide al usuario las coordenadas geográficas."""
    latitud = input("Ingrese la latitud: ")
    longitud = input("Ingrese la longitud: ")
    return (latitud, longitud)


# --------------------------------------------------------------------
# Función para consultar la API de Open-Meteo y devolver 
# la temperatura actual en el lugar indicado.
# --------------------------------------------------------------------
def obtener_temperatura_actual(lat, lon):
    """Realiza una consulta a la API de Open-Meteo para obtener el clima actual."""
    url = "https://api.open-meteo.com/v1/forecast"
    parametros = {
        "latitude": lat,
        "longitude": lon,
        "current_weather": True
    }
    respuesta = requests.get(url, params=parametros)
    datos = respuesta.json()
    return datos["current_weather"]["temperature"]


# --------------------------------------------------------------------
# Cuerpo principal del programa
# --------------------------------------------------------------------
# Solicitar latitud y longitud
ubicacion = solicitar_parametros()
lat = ubicacion[0]
lon = ubicacion[1]
temperatura = obtener_temperatura_actual(lat, lon)
print('Temperatura: ', temperatura)


