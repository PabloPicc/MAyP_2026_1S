# ============================================================
# Este programa consulta la API pública de Open-Meteo para
# obtener datos históricos de temperatura en una ubicación
# y período indicados por el usuario.
# Devuelve la temperatura máxima registrada en ese intervalo.
# ============================================================

import requests

# --------------------------------------------------------------------
# Función para solicitar parámetros al usuario
# --------------------------------------------------------------------
def solicitar_parametros():
    latitud = input("Ingrese la latitud: ")
    longitud = input("Ingrese la longitud: ")
    inicio = input("Ingrese la fecha de inicio (YYYY-MM-DD): ")
    fin = input("Ingrese la fecha de fin (YYYY-MM-DD): ")
    return (latitud, longitud, inicio, fin)

# --------------------------------------------------------------------
# Función para consultar la API de Open-Meteo y devolver el JSON
# --------------------------------------------------------------------
def consultar_api(lat, lon, start, end):
    # [BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR]
    pass

# --------------------------------------------------------------------
# Función para calcular la temperatura máxima de la lista temperaturas
# --------------------------------------------------------------------
def calcular_maximo(temperaturas):
    # [BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR]
    pass

# --------------------------------------------------------------------
# Cuerpo principal del programa
# --------------------------------------------------------------------
# Solicitar parámetros
params_usuario = solicitar_parametros()
lat = params_usuario[0]
lon = params_usuario[1]
start = params_usuario[2]
end = params_usuario[3]

# Consultar la API
# [COMPLETAR]

# Obtener la lista de temperaturas horarias
# [COMPLETAR]

# Calcular la máxima temperatura
# [COMPLETAR]

# Mostrar resultado
print("La temperatura máxima registrada entre las fechas indicadas fue de:")
# [COMPLETAR]


