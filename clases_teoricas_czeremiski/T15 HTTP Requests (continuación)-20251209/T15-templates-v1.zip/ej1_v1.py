# ============================================================
# Este programa consulta la API pública de Open-Meteo para
# obtener la temperatura actual en una ubicación especificada
# por el usuario.
# ============================================================

import requests

# --------------------------------------------------------------------
# Función para solicitar parámetros al usuario
# --------------------------------------------------------------------
def solicitar_parametros():
    """Pide al usuario las coordenadas geográficas."""
    latitud = input("Ingrese la latitud: ")
    longitud = input("Ingrese la longitud: ")
    return (latitud, longitud)


# --------------------------------------------------------------------
# Función para consultar la API de Open-Meteo y devolver el JSON
# --------------------------------------------------------------------
def consultar_api(lat, lon):
    # [BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR]
    pass


# --------------------------------------------------------------------
# Función para extraer y mostrar la temperatura actual
# --------------------------------------------------------------------
def mostrar_temperatura(datos):
    # [BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR]
    pass


# --------------------------------------------------------------------
# Cuerpo principal del programa
# --------------------------------------------------------------------
# Solicitar latitud y longitud
ubicacion = solicitar_parametros()
lat = ubicacion[0]
lon = ubicacion[1]

# Consultar la API
datos = consultar_api(lat, lon)

# Mostrar temperatura actual
mostrar_temperatura(datos)


