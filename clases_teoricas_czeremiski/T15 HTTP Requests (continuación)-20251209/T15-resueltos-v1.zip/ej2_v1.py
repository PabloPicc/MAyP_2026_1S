# ============================================================
# Este programa consulta la API pública de Open-Meteo para
# obtener datos históricos de temperatura en una ubicación
# y período indicados por el usuario.
# Devuelve la temperatura máxima registrada en ese intervalo.
# ============================================================

import requests

# --------------------------------------------------------------------
# Función para solicitar parámetros al usuario
# --------------------------------------------------------------------
def solicitar_parametros():
    latitud = input("Ingrese la latitud: ")
    longitud = input("Ingrese la longitud: ")
    inicio = input("Ingrese la fecha de inicio (YYYY-MM-DD): ")
    fin = input("Ingrese la fecha de fin (YYYY-MM-DD): ")
    return (latitud, longitud, inicio, fin)

# --------------------------------------------------------------------
# Función para consultar la API de Open-Meteo y devolver el JSON
# --------------------------------------------------------------------
def consultar_api(lat, lon, start, end):
    url = "https://archive-api.open-meteo.com/v1/archive"
    parametros = {
        "latitude": lat,
        "longitude": lon,
        "start_date": start,
        "end_date": end,
        "hourly": "temperature_2m"
    }
    respuesta = requests.get(url, params=parametros)
    return respuesta.json()

# --------------------------------------------------------------------
# Función para calcular la temperatura máxima de la lista temperaturas
# --------------------------------------------------------------------
def calcular_maximo(temperaturas):
    max_temp = temperaturas[0]
    for t in temperaturas:
        if t > max_temp:
            max_temp = t
    return max_temp

# --------------------------------------------------------------------
# Cuerpo principal del programa
# --------------------------------------------------------------------
# Solicitar parámetros
params_usuario = solicitar_parametros()
lat = params_usuario[0]
lon = params_usuario[1]
start = params_usuario[2]
end = params_usuario[3]

# Consultar la API
datos = consultar_api(lat, lon, start, end)

# Obtener la lista de temperaturas horarias
temperaturas = datos["hourly"]["temperature_2m"]

# Calcular la máxima temperatura
temp_max = calcular_maximo(temperaturas)

# Mostrar resultado
print("La temperatura máxima registrada entre las fechas indicadas fue de:")
print(temp_max, "°C")


