# Se importa la biblioteca de tests
import unittest
from ej_depuracion import esta, repetido, primer_repetido  # Se importa el codigo a testear

# Clase en la que se incluyen los tests
class TestPertenenciaYRepeticiones(unittest.TestCase):

    ######################## Tests para la función esta ########################
    def test_pertenencia(self):
        xs = [1,4,2,6]
        self.assertTrue(esta(1,xs))
        self.assertTrue(esta(2,xs))
        self.assertTrue(esta(4,xs))
        self.assertTrue(esta(6,xs))

    def test_no_pertenencia(self):
        xs = [1,4,2,6]
        self.assertFalse(esta(3,xs))
        self.assertFalse(esta(9,xs))

    ######################## Tests para la función repetido ####################
    def test_repetido(self):
        xs = [1,2,1,4,2,8]
        self.assertTrue(repetido(1,xs))
        self.assertTrue(repetido(2,xs))
        
    def test_no_repetido(self):
        xs = [1,2,1,4,2,8]
        self.assertFalse(repetido(4,xs))
        self.assertFalse(repetido(8,xs))

    ######################## Tests para primer_repetido ########################
    def test_primer_repetido_al_comienzo(self):
        xs = [1,2,1,4,2,8]
        self.assertEqual(primer_repetido(xs),1)
        
    def test_primer_repetido_no_al_cominezo(self):
        xs = [5,1,2,1,4,2,8]
        self.assertEqual(primer_repetido(xs),1)

unittest.main()
