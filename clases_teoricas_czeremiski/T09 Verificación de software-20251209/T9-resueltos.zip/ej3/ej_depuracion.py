########################################################

# Devuelve True si elem está en xs; y 
# False en caso contrario
def esta(elem, xs):
	encontrado = True
	i = 0
	while i < len(xs) and not encontrado:
		if xs[i] == elem:
			encontrado = True
		i = i+1
	return encontrado
   
# Devuelve True si elem está más de una 
# vez en xs; y False en caso contrario
def repetido(elem, xs):
	repetido = False
	i = 0
	while i < len(xs):
		if xs[i] == elem:
			repetido = True
		i = i+1
	return repetido

# Devuelve el primer elemento que aparece al 
# menos dos veces en xs.
# Precondición: en xs hay al menos un repetido.
def primer_repetido(xs):
   elems = set()
   for x in xs:
      elems.add(x)
      if x in elems:
         return x

