# Devuelve True si n es primo y False en caso contrario.
# La función es incorrecta porque falla para el 1.
def es_primo(n):
    for i in range(2,n): # { }
        if n % i == 0:
            return False
    return True
