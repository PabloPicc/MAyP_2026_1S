# Se importa la biblioteca de tests
import unittest
from suma_lista import suma  # Se importa el codigo a testear

# Clase en la que se incluyen los tests
class TestSumaLista(unittest.TestCase):

    # Test para listas que tienen solo números positivos
    def test_todos_positivos(self):
        self.assertEqual(suma([1,1,1,1]),4)
        self.assertEqual(suma([1,2,3,4]),10)

    # Test para listas que tienen solo números negativos
    def test_todos_negativos(self):
        self.assertEqual(suma([ -1,-1,-1,-1]),-4)
        self.assertEqual(suma([ -1,-2,-3,-4]),-10)

    # Test para listas que tienen números positivos y negativos
    def test_positivos_negativos(self):
        self.assertEqual(suma([1,2,3,-3]),3)
        self.assertEqual(suma([1,-1,1,-1]),0)

    # Test para la lista vacía
    def test_lista_vacia(self):
        self.assertEqual(suma([]),0)

unittest.main()
