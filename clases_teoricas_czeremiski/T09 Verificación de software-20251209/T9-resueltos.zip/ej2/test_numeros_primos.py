# Se importa la biblioteca de tests
import unittest
from numeros_primos import es_primo  #Se importa el código a testear

# Clase en la que incluiremos los tests
class TestPrimos(unittest.TestCase):

    # Test para números primos
    def test_primos(self):
        self.assertTrue(es_primo(5))
        self.assertTrue(es_primo(37))
        self.assertTrue(es_primo(101))

    # Test para números no primos
    def test_no_primos(self):
        self.assertFalse(es_primo(8))
        self.assertFalse(es_primo(44))
        self.assertFalse(es_primo(100))

    # Test para el número 1
    def test_uno(self):
        self.assertFalse(es_primo(1))

unittest.main()
