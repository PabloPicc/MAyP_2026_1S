# Devuelve la suma de todos los números de la lista xs
# La función es incorrecta porque falla para la lista vacía
def suma(xs):
    total = xs[0]
    i = 1
    while i < len(xs):
        total = total + xs[i]
        i = i + 1
    return total
