# Se importa la biblioteca de tests
import unittest
from suma_lista import suma  # Se importa el codigo a testear

# Clase en la que se incluyen los tests
class TestSumaLista(unittest.TestCase):

    # Borrar la siguiente línea y completar.
    pass


unittest.main()
