# Se importa la biblioteca de tests
import unittest
from numeros_primos import es_primo  #Se importa el código a testear

# Clase en la que incluiremos los tests
class TestPrimos(unittest.TestCase):

    # Borrar la siguiente línea y completar.
    pass

unittest.main()
