# Se importa la biblioteca de tests
import unittest
from ej_depuracion import esta, repetido, primer_repetido  # Se importa el codigo a testear

# Clase en la que se incluyen los tests
class TestPertenenciaYRepeticiones(unittest.TestCase):

    # Borrar las siguientes dos líneas y completar.
    # Incluir tests para las funciones esta, repetido y primer_repetido.
    pass


unittest.main()
