########################################################

# Devuelve True si elem está en lista; y 
# False en caso contrario
def esta(elem, lista):
	encontrado = True
	i = 0
	while i < len(lista) and not encontrado:
		if lista[i] == elem:
			encontrado = True
		i = i+1
	return encontrado
   
# Devuelve True si elem está más de una 
# vez en lista; y False en caso contrario
def repetido(elem, lista):
	repetido = False
	i = 0
	while i < len(lista):
		if lista[i] == elem:
			repetido = True
		i = i+1
	return repetido

# Devuelve el primer elemento que aparece al 
# menos dos veces en lista.
# Precondición: en lista hay al menos un repetido.
def primer_repetido(lista):
   elems = set()
   for x in lista:
      elems.add(x)
      if x in elems:
         return x

