def es_bisiesto(anio):
    ''' Devuelve True si anio es bisiesto; False en caso contrario. '''
    # Borrar la siguiente línea y completar
    pass

def contar_bisiestos(desde, hasta):
    ''' devuelve la cantidad de años bisiestos que se hay entre 'desde' y 'hasta'.'''
    # Borrar la siguiente línea y completar
    pass


# Cuerpo principal del programa: se imprimen los bisiestos entre 1900 y 2021
print(es_bisiesto(1984)) # imprime True
print(es_bisiesto(1985)) # imprime False
print(contar_bisiestos(1980, 1990)) # imprime 3: 1980. 1984 y 1988
