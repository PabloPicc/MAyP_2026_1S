import random

# ----------------------------------------------------------
# Ejercicio 3: Inversión con riesgo
# ----------------------------------------------------------
# Un inversor puede elegir entre:
# - un bono seguro que rinde 2% anual,
# - un proyecto riesgoso con:
#     * 15% de probabilidad de pérdida del 20%
#     * 85% de probabilidad de ganancia del 5%
#
# El objetivo es estimar, mediante simulación Montecarlo,
# el rendimiento promedio de cada alternativa.
# ----------------------------------------------------------

##### CUERPO PRINCIPAL DEL PROGRAMA #####

# COMPLETAR #

