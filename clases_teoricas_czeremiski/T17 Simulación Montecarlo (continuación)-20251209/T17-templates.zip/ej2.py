import random

# ----------------------------------------------------------
# Ejercicio 2: Dos compras consecutivas en un sitio web
# ----------------------------------------------------------
# Queremos estimar cuántas visitas realiza un usuario,
# en promedio, hasta que ocurre el primer caso de
# dos compras consecutivas.
#
# Cada visita es independiente y tiene probabilidad
# 0.3 de resultar en una compra.
# ----------------------------------------------------------


def simular_usuario():
  ''' Devuelve cuántas visitas hace un usuario hasta dos compras consecutivas. '''
  # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
  pass


##### CUERPO PRINCIPAL DEL PROGRAMA #####

# COMPLETAR #

