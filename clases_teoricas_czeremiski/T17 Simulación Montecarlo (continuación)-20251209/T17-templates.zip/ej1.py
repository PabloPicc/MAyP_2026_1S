import random

# ----------------------------------------------------------
# Ejercicio 1: Llamadas hasta la primera consulta de facturación
# ----------------------------------------------------------
# En un centro de atención telefónica, cada llamada puede ser
# de distintos tipos (consultas, reclamos, soporte, facturación).
# La probabilidad de que una llamada sea sobre facturación es 0.2.
#
# El objetivo es estimar, mediante simulación Montecarlo,
# cuántas llamadas se deben atender en promedio hasta recibir
# la primera consulta de facturación.
# ----------------------------------------------------------

def correr_experimento():
  ''' Devuelve cuántas llamadas se necesitan hasta la primera de facturación. '''
  # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
  pass


##### CUERPO PRINCIPAL DEL PROGRAMA #####

# COMPLETAR #

