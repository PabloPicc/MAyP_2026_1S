import random

# ----------------------------------------------------------
# Ejercicio 2: Dos compras consecutivas en un sitio web
# ----------------------------------------------------------
# Queremos estimar cuántas visitas realiza un usuario,
# en promedio, hasta que ocurre el primer caso de
# dos compras consecutivas.
#
# Cada visita es independiente y tiene probabilidad
# 0.3 de resultar en una compra.
# ----------------------------------------------------------


def simular_usuario():
  ''' Devuelve cuántas visitas hace un usuario hasta dos compras consecutivas. '''
  prob_compra = 0.3
  visitas = 0
  compras_consecutivas = 0

  while compras_consecutivas < 2:
    visitas += 1
    if random.random() < prob_compra:
      compras_consecutivas += 1
    else:
      compras_consecutivas = 0
  return visitas


##### CUERPO PRINCIPAL DEL PROGRAMA #####
N = 10000
total_visitas = 0
for _ in range(N):
  total_visitas += simular_usuario()

# Promedio de visitas necesarias
promedio_visitas = total_visitas / N
print("Promedio de visitas hasta dos compras consecutivas:", round(promedio_visitas, 2))

