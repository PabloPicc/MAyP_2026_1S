import random

# ----------------------------------------------------------
# Ejercicio 1: Llamadas hasta la primera consulta de facturación
# ----------------------------------------------------------
# En un centro de atención telefónica, cada llamada puede ser
# de distintos tipos (consultas, reclamos, soporte, facturación).
# La probabilidad de que una llamada sea sobre facturación es 0.2.
#
# El objetivo es estimar, mediante simulación Montecarlo,
# cuántas llamadas se deben atender en promedio hasta recibir
# la primera consulta de facturación.
# ----------------------------------------------------------

def correr_experimento():
  ''' Devuelve cuántas llamadas se necesitan hasta la primera de facturación. '''
  # Probabilidad de que una llamada sea de facturación representada por [0,2)
  p_facturacion = 0.2
  llamadas = 1
  while random.random() >= p_facturacion:
    llamadas = llamadas + 1
  return llamadas


##### CUERPO PRINCIPAL DEL PROGRAMA #####
N = 10000
total_llamadas = 0
for i in range(N):
  total_llamadas = total_llamadas + correr_experimento()

# Promedio de llamadas necesarias
promedio = total_llamadas / N
print("Promedio de llamadas hasta la primera consulta de facturación:", round(promedio, 2))

