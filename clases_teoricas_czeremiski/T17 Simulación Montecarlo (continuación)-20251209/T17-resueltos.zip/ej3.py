import random

# ----------------------------------------------------------
# Ejercicio 3: Inversión con riesgo
# ----------------------------------------------------------
# Un inversor puede elegir entre:
# - un bono seguro que rinde 2% anual,
# - un proyecto riesgoso con:
#     * 15% de probabilidad de pérdida del 20%
#     * 85% de probabilidad de ganancia del 5%
#
# El objetivo es estimar, mediante simulación Montecarlo,
# el rendimiento promedio de cada alternativa.
# ----------------------------------------------------------

N = 100000
suma_rendimientos_riesgo = 0
for i in range(N):
    # El proyecto riesgoso puede ganar o perder
    if random.random() < 0.15:
        suma_rendimientos_riesgo = suma_rendimientos_riesgo - .2   # -20%
    else:
        suma_rendimientos_riesgo = suma_rendimientos_riesgo + .05  # +5%

# Cálculo de rendimientos promedio
prom_bono = 0.02
prom_riesgo = suma_rendimientos_riesgo / N

print("Rendimiento promedio bono seguro:", prom_bono)
print("Rendimiento promedio proyecto riesgoso:", round(prom_riesgo, 3))

