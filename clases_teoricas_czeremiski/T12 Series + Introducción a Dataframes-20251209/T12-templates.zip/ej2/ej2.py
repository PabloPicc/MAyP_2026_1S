import pandas as pd

# 1. Crear un DataFrame a partir del archivo estudiantes.csv
[COMPLETAR]

# 2. Mostrar las primeras filas del DataFrame
# [COMPLETAR]

# 3. Crear un DataFrame con columnas nombre y promedio de las filas 2 y 4
# [COMPLETAR]

# 4. Crear un nuevo DataFrame ordenado por promedio en orden descendente
# [COMPLETAR]

# 5. Mostrar el registro del estudiante con el promedio más alto
# [COMPLETAR]

# 6. Guardar el DataFrame ordenado en un nuevo archivo CSV
# [COMPLETAR]
