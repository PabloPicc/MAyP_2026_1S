import pandas as pd

datos = {
    "Buenos Aires": 22,
    "Córdoba": 18,
    "Mendoza": 25,
    "Rosario": 20,
    "Salta": 26
}

# 1) Crear y mostrar una serie con las temperaturas promedio del dict datos
# [COMPLETAR]

# 2) Cálculos pedidos
print("\nCantidad de ciudades con temperatura registrada:")
# [COMPLETAR]

print("\nSuma de las temperaturas registradas:")
# [COMPLETAR]

print("\nTemperatura mínima registrada:")
# [COMPLETAR]

print("\nTemperatura máxima registrada:")
# [COMPLETAR]

print("\nTemperatura promedio registrada:")
# [COMPLETAR]

print("\nCiudades ordenadas por temperatura (de menor a mayor):")
# [COMPLETAR]

