# ejercicio1_series.py
# Solución al Ejercicio 1 sobre Series de pandas

import pandas as pd

# 1) Crear un diccionario con las temperaturas promedio
datos = {
    "Buenos Aires": 22,
    "Córdoba": 18,
    "Mendoza": 25,
    "Rosario": 20,
    "Salta": 26
}

# Crear la Series a partir del diccionario
temps = pd.Series(datos)
print("Series de temperaturas registradas:")
print(temps)
print()  # Línea en blanco para separar la salida

# 2) Cálculos pedidos
print("Cantidad de ciudades con temperatura registrada:")
print(temps.size)
print()

print("Suma de las temperaturas registradas:")
print(temps.sum())
print()

print("Temperatura mínima registrada:")
print(temps.min())
print()

print("Temperatura máxima registrada:")
print(temps.max())
print()

print("Temperatura promedio registrada:")
print(temps.mean())
print()

print("Ciudades ordenadas por temperatura (de menor a mayor):")
print(temps.sort_values())

