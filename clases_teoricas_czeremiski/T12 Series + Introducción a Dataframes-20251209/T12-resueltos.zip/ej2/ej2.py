# Solución Ejercicio 2: Manejo básico de DataFrames con pandas
import pandas as pd

# 1. Crear un DataFrame a partir del archivo estudiantes.csv
df_estudiantes = pd.read_csv("estudiantes.csv")  # Lee el CSV y crea el DataFrame

# 2. Mostrar las primeras filas del DataFrame
print() # Salto de línea para mejorar la legibilidad de la salida
print(df_estudiantes.head())

# 3. Crear un DataFrame con columnas nombre y promedio de las filas 2 y 4
print() # Salto de línea para mejorar la legibilidad de la salida
df_seleccion = df_estudiantes.loc[[2, 4], ["nombre", "promedio"]]
print(df_seleccion)

# 4. Crear un nuevo DataFrame ordenado por promedio en orden descendente
print() # Salto de línea para mejorar la legibilidad de la salida
df_promedios_dec = df_estudiantes.sort_values("promedio", ascending=False)
print(df_promedios_dec.head())

# 5. Mostrar el registro del estudiante con el promedio más alto
print() # Salto de línea para mejorar la legibilidad de la salida
mejor_estudiante = df_promedios_dec.iloc[0]
print(mejor_estudiante)

# 6. Guardar el DataFrame ordenado en un nuevo archivo CSV
df_promedios_dec.to_csv("estudiantes_por_promedio.csv", index=False)
