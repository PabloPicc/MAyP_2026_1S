# ============================================================
# ej2.py
# Red de alianzas entre empresas tecnológicas
# ============================================================

import networkx as nx
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# Función: cargar_alianzas
# Lee el archivo indicado y construye el grafo ponderado correspondiente.
# El peso de cada arista se guarda bajo la etiqueta "colaboraciones".
# ------------------------------------------------------------
def cargar_alianzas(nombre_archivo):
    # Cada línea del archivo tiene el formato:
    # empresa1,empresa2,colaboraciones
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


# ------------------------------------------------------------
# Función: dibujar_alianzas
# Dibuja la red de alianzas mostrando la cantidad de colaboraciones en las aristas.
# ------------------------------------------------------------
def dibujar_alianzas(G):
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


# ------------------------------------------------------------
# Función: mostrar_cantidad_alianzas
# Muestra la cantidad de alianzas (grado) de cada empresa.
# ------------------------------------------------------------
def mostrar_cantidad_alianzas(G):
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


# ------------------------------------------------------------
# Función: mostrar_cantidad_colaboraciones
# Calcula la suma total de colaboraciones (proyectos conjuntos) de cada empresa.
# ------------------------------------------------------------
def mostrar_cantidad_colaboraciones(G):
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


# ------------------------------------------------------------
# Cuerpo principal del programa
# ------------------------------------------------------------
G = cargar_alianzas("alianzas.csv")
dibujar_alianzas(G)
mostrar_cantidad_alianzas(G)
mostrar_cantidad_colaboraciones(G)
