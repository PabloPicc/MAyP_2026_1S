# ej1.py
# -------------------------------------------------------------------
# Este programa analiza una red de comercio internacional.
# Cada fila del archivo 'comercio.csv' indica que dos países
# mantienen una relación comercial. Se construye un
# con networkx y se realizan análisis básicos.
# -------------------------------------------------------------------

import networkx as nx
import matplotlib.pyplot as plt


def construir_grafo(nombre_archivo):
    """
    Lee un archivo CSV sin encabezado que contiene pares de países
    y construye el grafo correspondiente.
    """
    G = nx.read_edgelist(nombre_archivo, delimiter=",", encoding="utf-8")
    return G


def mostrar_informacion_basica(G):
    """
    Muestra el número de nodos (países) y aristas (relaciones comerciales).
    """
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


def listar_relaciones(G):
    """
    Muestra los países con los que comercia cada país.
    """
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


def mostrar_cantidad_socios_comerciales(G):
    """
    Muestra cuántos socios comerciales tiene cada país (grado del nodo).
    """
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


def mostrar_pais_con_mas_socios_comerciales(G):
    """
    Muestra el país con más socios comerciales
    y la cantidad de conexiones que tiene.
    """
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


def verificar_conectividad(G):
    """
    Verifica si la red de comercio es conexa
    (si todos los países están conectados).
    """
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


def dibujar_grafo(G):
    """Dibuja el grafo mostrando los nombres de los países."""
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


# -------------------------------------------------------------------
# Programa principal
# -------------------------------------------------------------------

# 1. Construye el grafo a partir del archivo CSV
G = construir_grafo("comercio.csv")

# 2. Muestra información general
mostrar_informacion_basica(G)

# 3. Muestra las relaciones comerciales de cada país
listar_relaciones(G)

# 4. Mostrar la cantidad de socios comerciales de cada país
mostrar_cantidad_socios_comerciales(G)

# 5. Muestra el país con más socios comerciales
mostrar_pais_con_mas_socios_comerciales(G)

# 6. Verifica si todos los países están conectados mediante socios comerciales
verificar_conectividad(G)

# 7. Dibuja el grafo
dibujar_grafo(G)
