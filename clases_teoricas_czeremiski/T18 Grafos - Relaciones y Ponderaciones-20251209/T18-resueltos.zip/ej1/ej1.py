# ej1.py
# -------------------------------------------------------------------
# Este programa analiza una red de comercio internacional.
# Cada fila del archivo 'comercio.csv' indica que dos países
# mantienen una relación comercial. Se construye un
# con networkx y se realizan análisis básicos.
# -------------------------------------------------------------------

import networkx as nx
import matplotlib.pyplot as plt


def construir_grafo(nombre_archivo):
    """
    Lee un archivo CSV sin encabezado que contiene pares de países
    y construye el grafo correspondiente.
    """
    G = nx.read_edgelist(nombre_archivo, delimiter=",", encoding="utf-8")
    return G


def mostrar_informacion_basica(G):
    """
    Muestra el número de nodos (países) y aristas (relaciones comerciales).
    """
    print("Número de países (nodos):", G.number_of_nodes())
    print("Número de relaciones comerciales (aristas):", G.number_of_edges())


def listar_relaciones(G):
    """
    Muestra los países con los que comercia cada país.
    """
    print("\nRelaciones comerciales por país:")
    for nodo in G:
        print(" -", nodo, "↔", list(G.neighbors(nodo)))


def mostrar_cantidad_socios_comerciales(G):
    """
    Muestra cuántos socios comerciales tiene cada país (grado del nodo).
    """
    print("\nNúmero de socios comerciales por país:")
    for nodo in G:
        print(" -", nodo, ":", G.degree(nodo))


def mostrar_pais_con_mas_socios_comerciales(G):
    """
    Muestra el país con más socios comerciales
    y la cantidad de conexiones que tiene.
    """
    max_grado = 0
    pais_max = None
    for nodo in G:
        if G.degree(nodo) > max_grado:
            max_grado = G.degree(nodo)
            pais_max = nodo
    print('\nPaís con más socios comerciales:', pais_max, '\nCantidad de socios:', max_grado)


def verificar_conectividad(G):
    """
    Verifica si la red de comercio es conexa
    (si todos los países están conectados).
    """
    if nx.is_connected(G):
        print("\nLa red de comercio es conexa.")
    else:
        print("\nLa red de comercio NO es conexa.")


def dibujar_grafo(G):
    """Dibuja el grafo mostrando los nombres de los países."""
    print("\nMostrando grafo...")
    pos = nx.spring_layout(G, seed=42)  # disposición automática
    nx.draw(G, pos, with_labels=True, node_color="lightblue", node_size=900, font_size=9)
    plt.show()


# -------------------------------------------------------------------
# Programa principal
# -------------------------------------------------------------------

# 1. Construye el grafo a partir del archivo CSV
G = construir_grafo("comercio.csv")

# 2. Muestra información general
mostrar_informacion_basica(G)

# 3. Muestra las relaciones comerciales de cada país
listar_relaciones(G)

# 4. Mostrar la cantidad de socios comerciales de cada país
mostrar_cantidad_socios_comerciales(G)

# 5. Muestra el país con más socios comerciales
mostrar_pais_con_mas_socios_comerciales(G)

# 6. Verifica si todos los países están conectados mediante socios comerciales
verificar_conectividad(G)

# 7. Dibuja el grafo
dibujar_grafo(G)
