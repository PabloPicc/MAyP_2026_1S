# ============================================================
# ej2.py
# Red de alianzas entre empresas tecnológicas
# ============================================================

import networkx as nx
import matplotlib.pyplot as plt

# ------------------------------------------------------------
# Función: cargar_alianzas
# Lee el archivo indicado y construye el grafo ponderado correspondiente.
# El peso de cada arista se guarda bajo la etiqueta "colaboraciones".
# ------------------------------------------------------------
def cargar_alianzas(nombre_archivo):
    # Cada línea del archivo tiene el formato:
    # empresa1,empresa2,colaboraciones
    G = nx.read_edgelist(nombre_archivo,
                         delimiter=",",
                         data=[("colaboraciones", int)])
    return G


# ------------------------------------------------------------
# Función: dibujar_alianzas
# Dibuja la red de alianzas mostrando la cantidad de colaboraciones en las aristas.
# ------------------------------------------------------------
def dibujar_alianzas(G):
    pos = nx.spring_layout(G, seed=42)
    cant_colaboraciones = nx.get_edge_attributes(G, "colaboraciones")

    plt.figure(figsize=(6, 4))
    nx.draw(G, pos, with_labels=True, node_color="lightblue", node_size=1500)
    nx.draw_networkx_edge_labels(G, pos, edge_labels=cant_colaboraciones)
    plt.title("Red de alianzas entre empresas tecnológicas")
    plt.tight_layout()
    plt.show()


# ------------------------------------------------------------
# Función: mostrar_cantidad_alianzas
# Muestra la cantidad de alianzas (grado) de cada empresa.
# ------------------------------------------------------------
def mostrar_cantidad_alianzas(G):
    print("\nCantidad de alianzas (grado) de cada empresa:\n")
    for empresa in G:
        grado = G.degree(empresa)
        print("Empresa:", empresa, "-> alianzas:", grado)


# ------------------------------------------------------------
# Función: mostrar_cantidad_colaboraciones
# Calcula la suma total de colaboraciones (proyectos conjuntos) de cada empresa.
# ------------------------------------------------------------
def mostrar_cantidad_colaboraciones(G):
    print("\nCantidad total de colaboraciones (proyectos conjuntos):\n")
    for empresa in G:
        total = 0
        for vecino in G[empresa]:
            total = total + G[empresa][vecino]["colaboraciones"]
        print("Empresa:", empresa, "-> colaboraciones totales:", total)


# ------------------------------------------------------------
# Cuerpo principal del programa
# ------------------------------------------------------------
G = cargar_alianzas("alianzas.csv")
dibujar_alianzas(G)
mostrar_cantidad_alianzas(G)
mostrar_cantidad_colaboraciones(G)
