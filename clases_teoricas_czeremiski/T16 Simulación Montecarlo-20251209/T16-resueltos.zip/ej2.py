# ej2.py
# -----------------------------------------------------
# Simulación Montecarlo: pedidos en un restaurante
# -----------------------------------------------------
# En un restaurante, cada cliente elige su comida al azar
# entre cuatro opciones: pizza, empanadas, ensalada y milanesa.
#
# Se atienden 3 clientes independientes.
# Queremos estimar la probabilidad de que al menos uno
# pida pizza.
# -----------------------------------------------------

import random

# -----------------------------------------------------
# Función: obtener_pedidos
# -----------------------------------------------------
# Devuelve una lista con los pedidos de los tres comensales.
# Cada pedido se elige al azar entre las cuatro opciones
# disponibles en el menú.
# -----------------------------------------------------
def obtener_pedidos():
    res = []
    for i in range(3):
        pedido = random.choice(['pizza', 'empanadas', 'ensalada', 'milanesa'])
        res.append(pedido)
    return res


############## Cuerpo principal del programa ##############

# Número total de simulaciones (experimentos Montecarlo)
N = 10000

# Contador de simulaciones en las que al menos un cliente pidió pizza
contador_pizza = 0

for i in range(N):
    # Generamos los pedidos de los tres clientes
    pedidos = obtener_pedidos()

    # Verificamos si al menos uno pidió pizza
    if 'pizza' in pedidos:
        contador_pizza += 1

# Estimamos la probabilidad como proporción de casos favorables
probabilidad = contador_pizza / N

# Mostramos el resultado
print("Probabilidad estimada de que al menos uno pida pizza:", probabilidad)
