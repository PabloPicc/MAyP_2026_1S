# ej1.py
# -----------------------------------------------------
# Simulación Montecarlo: cartas numeradas del 1 al 10
# -----------------------------------------------------
# Se extraen dos cartas numeradas del 1 al 10 (con reemplazo).
# Queremos estimar la probabilidad de que al menos una
# de las dos cartas tenga un valor mayor o igual a 8.
# -----------------------------------------------------

import random

# Número total de simulaciones (experimentos Montecarlo)
N = 10000

# Contador de casos favorables (éxitos)
exitos = 0

for i in range(N):
    # Extraemos dos cartas al azar (valores entre 1 y 10)
    carta1 = random.randint(1, 10)
    carta2 = random.randint(1, 10)

    # Verificamos si al menos una carta es mayor o igual a 8
    if carta1 >= 8 or carta2 >= 8:
        exitos += 1

# Estimación de la probabilidad como proporción de éxitos
prob = exitos / N

# Mostramos el resultado
print("Probabilidad estimada de que al menos una carta sea ≥ 8:", prob)
