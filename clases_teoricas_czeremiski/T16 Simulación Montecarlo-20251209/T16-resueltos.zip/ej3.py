# ej3.py
# -----------------------------------------------------
# Simulación Montecarlo: temperatura en verano
# -----------------------------------------------------
# La temperatura diaria en una ciudad durante el verano
# varía uniformemente entre 20°C y 35°C.
#
# Queremos estimar la probabilidad de que un día
# haga menos de 25°C.
# -----------------------------------------------------

import random

# 1. Número de simulaciones (días)
N = 10000

# 2. Contador de días con temperatura < 25°C
contador_frio = 0

for i in range(N):
    # Simulamos la temperatura del día
    temp = random.uniform(20, 35)

    # Verificamos si es menor a 25°C
    if temp < 25:
        contador_frio += 1

# 3. Estimación de la probabilidad
probabilidad = contador_frio / N

# 4. Mostrar resultado
print("Probabilidad estimada de temperatura < 25°C:", probabilidad)
