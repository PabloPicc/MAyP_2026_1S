# ej4.py
# -----------------------------------------------------
# Simulación Montecarlo: demora total de entrega
# -----------------------------------------------------
# Una empresa realiza entregas a domicilio.
# El tiempo total (en minutos) se compone de tres partes
# aleatorias e independientes:
#
#   X1: Preparación  ~ Uniforme(5, 15)
#   X2: Transporte    ~ Normal(20, 5)
#   X3: Tráfico       ~ Normal(10, 3)
#
# Queremos estimar la probabilidad de que la entrega total
# tarde 40 minutos o más.
#
# Además, calcularemos el tiempo promedio total de entrega.
# -----------------------------------------------------

import random

# Número total de simulaciones
N = 10000

exitos = 0           # cantidad de entregas con demora ≥ 40
suma_totales = 0     # acumulador de todos los tiempos simulados

for i in range(N):
    # Generamos las tres componentes aleatorias
    prep = random.uniform(5, 15)       # tiempo de preparación
    trans = random.gauss(20, 5)        # tiempo de transporte
    traf = random.gauss(10, 3)         # demora por tráfico

    # Calculamos el tiempo total de entrega
    total = prep + trans + traf

    # Verificamos si el total supera los 40 minutos
    if total >= 40:
        exitos = exitos + 1

    # Acumulamos el total para calcular el promedio
    suma_totales = suma_totales + total

# Cálculo de la probabilidad estimada y del promedio
probabilidad = exitos / N
promedio_total = suma_totales / N

# Mostramos los resultados
print("Probabilidad estimada de que la entrega tarde ≥ 40 min:", probabilidad)
print("Tiempo promedio total de entrega:", promedio_total)
