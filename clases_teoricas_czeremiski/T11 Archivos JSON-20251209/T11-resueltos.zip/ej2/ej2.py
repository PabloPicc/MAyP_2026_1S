import json
from calzado import Calzado

def serializar_calzado(cal, archivo_json):
    # Se crean diccionarios con los datos
    calzado_json = dict()
    calzado_json['marca'] = cal.marca
    calzado_json['modelo'] = cal.modelo
    calzado_json['precio'] = cal.precio

    # Se abre el archivo destino en modo escritura
    f = open(archivo_json, 'w')
    # Se escriben los datos como objeto JSON
    json.dump(calzado_json, f, indent=4)
    # Se cierra el archivo
    f.close()

c = Calzado('Puma', 'Suede', 33699.00)
serializar_calzado(c, 'puma_suede.json')
