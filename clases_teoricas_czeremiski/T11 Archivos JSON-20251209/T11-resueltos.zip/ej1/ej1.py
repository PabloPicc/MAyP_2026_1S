import json

def cargar_diccionario(nom_archivo):
    f = open(nom_archivo)
    datos = json.load(f)
    return datos

def mostrar_info(nom_archivo):
    ''' Muestra por consola la información contenida en el archivo JSON nom_archivo. '''
    datos = cargar_diccionario(nom_archivo)
    print(datos)

def promedio(nom_archivo):
    ''' Devuelve el promedio del estudiante a partir de los datos almacenados en el archivo JSON nom_archivo. '''
    datos = cargar_diccionario(nom_archivo)
    materias = datos['materias']
    suma_notas = 0
    for m in materias:
        suma_notas = suma_notas + m['nota']
    return suma_notas/len(materias)


#mostrar_info('ana_perez.json')
#mostrar_info('juan_gomez.json')
print('El promedio de Ana es ' + str(promedio('ana_perez.json')))     # 7.0
print('El promedio de Juan es ' + str(promedio('juan_gomez.json')))   # 6.5

