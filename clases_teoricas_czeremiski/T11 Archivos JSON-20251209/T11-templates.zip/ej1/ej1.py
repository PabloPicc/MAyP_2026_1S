import json

def mostrar_info(nom_archivo):
    ''' Muestra por consola la información contenida en el archivo JSON nom_archivo. '''
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass

def promedio(nom_archivo):
    ''' Devuelve el promedio del estudiante a partir de los datos almacenados en el archivo JSON nom_archivo. '''
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


#mostrar_info('ana_perez.json')
#mostrar_info('juan_gomez.json')
print('El promedio de Ana es ' + str(promedio('ana_perez.json')))     # 7.0
print('El promedio de Juan es ' + str(promedio('juan_gomez.json')))   # 6.5

