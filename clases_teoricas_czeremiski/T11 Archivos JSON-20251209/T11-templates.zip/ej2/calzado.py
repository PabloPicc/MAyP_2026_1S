# Clase para representar calzados
class Calzado:

    # Constructor
    def __init__(self, mar, mod, pre):
        self.marca = mar
        self.modelo = mod
        self.precio = pre


