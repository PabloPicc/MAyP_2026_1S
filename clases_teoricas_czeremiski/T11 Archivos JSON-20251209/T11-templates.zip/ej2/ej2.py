import json
from calzado import Calzado

def serializar_calzado(cal, archivo_json):
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass

c = Calzado('Puma', 'Suede', 33699.00)
serializar_calzado(c, 'puma_suede.json')
