def digitos(numero):
    ''' Dado un string que representa un número devuelve un string que enumera sus dígitos. '''
    # Borrar la siguiente línea y completar
    pass

# Cuerpo principal del programa
print(digitos('4137'))
print(digitos('0'))
print(digitos('11'))
print(digitos('13579'))
