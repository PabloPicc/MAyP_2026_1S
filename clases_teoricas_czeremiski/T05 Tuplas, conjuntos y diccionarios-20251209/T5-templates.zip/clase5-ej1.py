# Función que dada una palabra devuelve
# el conjutno de todas sus letras.
def letras(palabra):
    ''' Devuelve un conjunto con todas las letras de palabra. '''
    # Borrar la siguiente línea y completar
    pass

def letras_en_comun(pal1, pal2):
    ''' Devuelve un conjunto con las letras que aparecen tanto en pal1 como en pal2. '''
    # Borrar la siguiente línea y completar
    pass

# Cuerpo principal del programa.
a = letras('perezosos')
print(a)
b = letras_en_comun('pala', 'pelo')
print(b)
