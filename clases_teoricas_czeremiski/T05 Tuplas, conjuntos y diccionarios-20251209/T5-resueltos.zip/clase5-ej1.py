# Función que dada una palabra devuelve
# el conjutno de todas sus letras.
def letras(palabra):
    rv = set()
    for letra in palabra:
        rv.add(letra)
    return rv

# Función que dadas dos palabras devuelve
# el conjutno de letras que tienen en común.
def letras_en_comun(pal1, pal2):
    c1 = letras(pal1)
    c2 = letras(pal2)
    return c1 & c2


# Cuerpo principal del programa.
a = letras('perezosos')
print(a)

b = letras_en_comun('pala', 'pelo')
print(b)
