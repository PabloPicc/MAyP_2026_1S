# En este archivo hay dos funciones distintas que
# dado un string que representa un número devuelve
# un string que enumera sus dígitos.
# Ej: para '321', devuelve 'tres dos uno'.

# Versión 1
def digitos_v1(numero):
    # Se crea el diccionario que asocia dígitos son sus nombres
    d = dict()
    d['0'] = 'cero'
    d['1'] = 'uno'
    d['2'] = 'dos'
    d['3'] = 'tres'
    d['4'] = 'cuatro'
    d['5'] = 'cinco'
    d['6'] = 'seis'
    d['7'] = 'siete'
    d['8'] = 'ocho'
    d['9'] = 'nueve'

    # En res se iran concatenando las palabras asociadas a
    # los dígitos a medida que se van leyendo. Antes
    # del ciclo res es el string vacío porque a esa altura
    # no se leyó ningún dígito.
    res = ''
    for dig in numero:
        res = res + d[dig] + ' '
    return res


# Versión 2
def digitos_v2(numero):
    # Se crea el diccionario que asocia dígitos son sus nombres
    d = dict()
    d['0'] = 'cero'
    d['1'] = 'uno'
    d['2'] = 'dos'
    d['3'] = 'tres'
    d['4'] = 'cuatro'
    d['5'] = 'cinco'
    d['6'] = 'seis'
    d['7'] = 'siete'
    d['8'] = 'ocho'
    d['9'] = 'nueve'

    # En la lista a se guardan las palabras
    # Ej: ['tres', 'dos', ...],
    a = []
    for digito in numero:
        a.append(d[digito])

    # Se devuelve un string con los strings
    # de a separados por un espacio.
    return ' '.join(a)

# Cuerpo principal del programa
print('Pruebas de la vesión 1')
print(digitos_v1('4137'))
print(digitos_v1('0'))
print(digitos_v1('11'))
print(digitos_v1('13579'))
print()

print('Pruebas de la versión 2')
print(digitos_v2('4137'))
print(digitos_v2('0'))
print(digitos_v2('11'))
print(digitos_v2('13579'))
