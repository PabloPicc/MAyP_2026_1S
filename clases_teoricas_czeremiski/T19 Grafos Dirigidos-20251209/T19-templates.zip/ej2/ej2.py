"""
Este programa analiza una red de estaciones conectadas por rutas que transportan pasajeros.
Cada línea del archivo CSV representa un viaje desde una estación origen hacia una estación destino,
con un número que indica la cantidad promedio de pasajeros transportados.

El programa:

1. Carga la red desde un archivo CSV.
2. Muestra la estructura de la red de transporte.
3. Indica cuántos pasajeros llegan y cuántos salen de cada estación.
4. Determina cuál es la estación con mayor tráfico total (entrante + saliente).
"""

import networkx as nx
import matplotlib.pyplot as plt


# ----------------------------------------------------------
# Inciso (a)
# ----------------------------------------------------------
def cargar_red_desde_csv(ruta_csv):
    """
    Carga un grafo dirigido desde un archivo CSV usando nx.read_edgelist.

    El CSV debe tener:
        origen,destino,cant_promedio_pasajeros

    Se genera un DiGraph donde:
    - Los nodos son estaciones.
    - Las aristas representan viajes.
    - El atributo 'cant_promedio_pasajeros' indica la cantidad promedio de pasajeros.
    """
    G = nx.read_edgelist(
        ruta_csv,
        delimiter=",",
        create_using=nx.DiGraph(),
        data=[("cant_promedio_pasajeros", int)]
    )

    return G


# ----------------------------------------------------------
# Inciso (b)
# ----------------------------------------------------------
def dibujar_grafo(G):
    """
    Dibuja el grafo con flechas que indican el tráfico entre estaciones.
    """
    # TODO: Borrar la siguiente línea y completar
    pass


# ----------------------------------------------------------
# Inciso (c)
# ----------------------------------------------------------
def mostrar_trafico(G):
    """
    Imprime todas la cantidad de pasajeros que llegan y parten de las estaciones.
    """
    # TODO: Borrar la siguiente línea y completar
    pass


# ----------------------------------------------------------
# Inciso (d)
# ----------------------------------------------------------
def estacion_mayor_trafico(G):
    """
    Encuentra la estación con mayor tráfico total.

    El tráfico total se define como:
    - la suma de pasajeros promedio que salen de la estación,
    - más la suma de pasajeros promedio que llegan a la estación.

    Devuelve la tupla (estación, tráfico) que maximiza tráfico.
    """
    # TODO: Borrar la siguiente línea y completar
    pass



# ----------------------------------------------------------
# PROGRAMA PRINCIPAL
# ----------------------------------------------------------

ruta = "pasajeros.csv"

red = cargar_red_desde_csv(ruta)

dibujar_grafo(red)

mostrar_trafico(red)

est_max_trafico = estacion_mayor_trafico(red)

print("")
print("La estación con mayor tráfico total es: " + est_max_trafico[0])
print("Tráfico total promedio: " + str(est_max_trafico[1]))
