# ==============================================================
# ej1.py
# ==============================================================
# Este script trabaja con un grafo dirigido que representa
# transferencias electrónicas entre cuentas bancarias.
# Cada nodo es una cuenta, y cada arista dirigida (u, v)
# indica que la cuenta u transfirió dinero a la cuenta v.
# ==============================================================

import networkx as nx
import matplotlib.pyplot as plt

# --------------------------------------------------------------
# (a) Cargar el grafo dirigido desde el archivo CSV
# --------------------------------------------------------------

def cargar_transferencias(nombre_archivo):
    """
    Carga las transferencias desde un archivo CSV sin encabezado
    y construye un grafo dirigido.
    Cada fila del archivo debe tener el formato:
        origen, destino
    """
    G = nx.read_edgelist(
        nombre_archivo,
        delimiter=",",              # separador de columnas
        create_using=nx.DiGraph()   # tipo de grafo: dirigido
    )
    return G


# --------------------------------------------------------------
# (b) Dibujar el grafo
# --------------------------------------------------------------

def dibujar_grafo(G):
    """
    Dibuja el grafo con flechas que indican el sentido
    de las transferencias.
    """
    # TODO: Borrar la siguiente línea y completar
    pass


# --------------------------------------------------------------
# (c) Para cada cuenta, muestra quienes le transfieren y
# a quienes les transfiere.
# --------------------------------------------------------------

def transferencias(G):
    """
    Para cada cuenta, muestra:
    - Las cuentas que le transfieren
    - Las cuentas a las que transfiere
    """
    # TODO: Borrar la siguiente línea y completar
    pass


# --------------------------------------------------------------
# (d) y (e) Calcular cantidad de transferencias hechas y recibidas
# --------------------------------------------------------------

def cantidad_de_transferencias_por_cuenta(G):
    """
    Muestra la cantidad de transferencias hechas (out-degree)
    y recibidas (in-degree) por cada cuenta.
    """
    # TODO: Borrar la siguiente línea y completar
    pass


# --------------------------------------------------------------
# Código principal
# --------------------------------------------------------------

archivo = "transferencias.csv"

# (a) Cargar grafo dirigido
G = cargar_transferencias(archivo)

# (b) Dibujar el grafo
dibujar_grafo(G)

# (c) Mostrar quién transfiere a quién
transferencias(G)

# (d) y (e) Mostrar la cantidad de transferencias realizadas y recibidas por cada cuenta
cantidad_de_transferencias_por_cuenta(G)
