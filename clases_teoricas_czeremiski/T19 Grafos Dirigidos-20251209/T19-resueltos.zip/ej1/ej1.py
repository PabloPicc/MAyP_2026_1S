# ==============================================================
# ej1.py
# ==============================================================
# Este script trabaja con un grafo dirigido que representa
# transferencias electrónicas entre cuentas bancarias.
# Cada nodo es una cuenta, y cada arista dirigida (u, v)
# indica que la cuenta u transfirió dinero a la cuenta v.
# ==============================================================

import networkx as nx
import matplotlib.pyplot as plt

# --------------------------------------------------------------
# (a) Cargar el grafo dirigido desde el archivo CSV
# --------------------------------------------------------------

def cargar_transferencias(nombre_archivo):
    """
    Carga las transferencias desde un archivo CSV sin encabezado
    y construye un grafo dirigido.
    Cada fila del archivo debe tener el formato:
        origen, destino
    """
    G = nx.read_edgelist(
        nombre_archivo,
        delimiter=",",              # separador de columnas
        create_using=nx.DiGraph()   # tipo de grafo: dirigido
    )
    return G


# --------------------------------------------------------------
# (b) Dibujar el grafo
# --------------------------------------------------------------

def dibujar_grafo(G):
    """
    Dibuja el grafo con flechas que indican el sentido
    de las transferencias.
    """
    plt.figure(figsize=(6, 5))
    pos = nx.spring_layout(G, seed=7)  # disposición automática

    nx.draw_networkx_nodes(G, pos, node_color="lightblue", node_size=900)
    nx.draw_networkx_edges(G, pos, arrows=True, arrowstyle="->", arrowsize=15)
    nx.draw_networkx_labels(G, pos, font_size=8)

    plt.title("Red de transferencias bancarias", fontsize=10)
    plt.axis("off")
    plt.tight_layout()
    plt.show()


# --------------------------------------------------------------
# (c) Mostrar predecesores (quiénes le transfieren) y sucesores
# (a quiénes transfiere) de cada cuenta
# --------------------------------------------------------------

def transferencias(G):
    """
    Para cada nodo, muestra:
    - Los nodos que le transfieren (predecesores)
    - Los nodos a los que transfiere (sucesores)
    """
    for nodo in G.nodes():
        sucesores = list(G.successors(nodo))
        predecesores = list(G.predecessors(nodo))
        print("\nCuenta:", nodo)
        print("  Transfiere a:", sucesores)
        print("  Recibe de:", predecesores)


# --------------------------------------------------------------
# (d) y (e) Calcular cantidad de transferencias hechas y recibidas
# --------------------------------------------------------------

def cantidad_de_transferencias_por_cuenta(G):
    """
    Muestra la cantidad de transferencias hechas (out-degree)
    y recibidas (in-degree) por cada cuenta.
    """
    print("\n=== Cantidad de transferencias hechas (out-degree) ===")
    for nodo in G:
        print(nodo + " : " + str(G.out_degree(nodo)))

    print("\n=== Cantidad de transferencias recibidas (in-degree) ===")
    for nodo in G:
        print(nodo + " : " + str(G.in_degree(nodo)))


# --------------------------------------------------------------
# Código principal
# --------------------------------------------------------------

archivo = "transferencias.csv"

# (a) Cargar grafo dirigido
G = cargar_transferencias(archivo)

# (b) Dibujar el grafo
dibujar_grafo(G)

# (c) Mostrar quién transfiere a quién
transferencias(G)

# (d) y (e) Mostrar la cantidad de transferencias realizadas y recibidas por cada cuenta
cantidad_de_transferencias_por_cuenta(G)
