"""
Este programa analiza una red de estaciones conectadas por rutas que transportan pasajeros.
Cada línea del archivo CSV representa un viaje desde una estación origen hacia una estación destino,
con un número que indica la cantidad promedio de pasajeros transportados.

El programa:

1. Carga la red desde un archivo CSV.
2. Muestra la estructura de la red de transporte.
3. Indica cuántos pasajeros llegan y cuántos salen de cada estación.
4. Determina cuál es la estación con mayor tráfico total (entrante + saliente).
"""

import networkx as nx
import matplotlib.pyplot as plt


# ----------------------------------------------------------
# Inciso (a)
# ----------------------------------------------------------
def cargar_red_desde_csv(ruta_csv):
    """
    Carga un grafo dirigido desde un archivo CSV usando nx.read_edgelist.

    El CSV debe tener:
        origen,destino,cant_promedio_pasajeros

    Se genera un DiGraph donde:
    - Los nodos son estaciones.
    - Las aristas representan viajes.
    - El atributo 'cant_promedio_pasajeros' indica la cantidad promedio de pasajeros.
    """
    G = nx.read_edgelist(
        ruta_csv,
        delimiter=",",
        create_using=nx.DiGraph(),
        data=[("cant_promedio_pasajeros", int)]
    )

    return G


# ----------------------------------------------------------
# Inciso (b)
# ----------------------------------------------------------
def dibujar_grafo(G):
    """
    Dibuja el grafo con flechas que indican el tráfico entre estaciones.
    """
    plt.figure(figsize=(6, 5))
    pos = nx.spring_layout(G, seed=7)  # disposición automática

    nx.draw_networkx_nodes(G, pos, node_color="lightblue", node_size=900)
    nx.draw_networkx_edges(G, pos, arrows=True, arrowstyle="->", arrowsize=15)
    nx.draw_networkx_labels(G, pos, font_size=8)

    plt.title("Red de transporte", fontsize=10)
    plt.axis("off")
    plt.tight_layout()
    plt.show()


# ----------------------------------------------------------
# Inciso (c)
# ----------------------------------------------------------
def mostrar_trafico(G):
    """
    Imprime todas la cantidad de pasajeros que llegan y parten de las estaciones.
    """
    print("Tráfico de pasajeros:")

    for estacion in G:
        pasajeros_que_salen = 0
        sucesores = G.successors(estacion)
        for destino in sucesores:
            cant = G[estacion][destino]["cant_promedio_pasajeros"]
            pasajeros_que_salen = pasajeros_que_salen + cant

        pasajeros_que_llegan = 0
        predecesores = G.predecessors(estacion)
        for origen in predecesores:
            cant = G[origen][estacion]["cant_promedio_pasajeros"]
            pasajeros_que_llegan = pasajeros_que_llegan + cant

        print("Pasajeros que llegan a " + estacion + ": " + str(pasajeros_que_llegan))
        print("Pasajeros que salen de " + estacion + ": " + str(pasajeros_que_salen))


# ----------------------------------------------------------
# Inciso (d)
# ----------------------------------------------------------
def estacion_mayor_trafico(G):
    """
    Encuentra la estación con mayor tráfico total.

    El tráfico total se define como:
    - la suma de pasajeros promedio que salen de la estación,
    - más la suma de pasajeros promedio que llegan a la estación.

    Devuelve la tupla (estación, tráfico) que maximiza tráfico.
    """
    maxima_estacion = None
    max_trafico = 0

    for estacion in G:

        total = 0

        # Sumar tráfico saliente: aristas (estacion -> vecino)
        sucesores = G.successors(estacion)
        for v in sucesores:
            datos = G[estacion][v]
            total = total + datos["cant_promedio_pasajeros"]

        # Sumar tráfico entrante: aristas (vecino -> estacion)
        predecesores = G.predecessors(estacion)
        for u in predecesores:
            datos = G[u][estacion]
            total = total + datos["cant_promedio_pasajeros"]

        if total > max_trafico:
            max_trafico = total
            maxima_estacion = estacion

    return (maxima_estacion, max_trafico)



# ----------------------------------------------------------
# PROGRAMA PRINCIPAL
# ----------------------------------------------------------

ruta = "pasajeros.csv"

red = cargar_red_desde_csv(ruta)

dibujar_grafo(red)

mostrar_trafico(red)

est_max_trafico = estacion_mayor_trafico(red)

print("")
print("La estación con mayor tráfico total es: " + est_max_trafico[0])
print("Tráfico total promedio: " + str(est_max_trafico[1]))
