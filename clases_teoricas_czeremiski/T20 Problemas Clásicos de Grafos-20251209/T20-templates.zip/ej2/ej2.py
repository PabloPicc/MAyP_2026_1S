import networkx as nx

# -------------------------------------------------------------------
# Cargar costos desde el archivo CSV.
# El formato de cada línea es:
#    C1,P1,4
# donde:
#    - primer campo: consultor
#    - segundo campo: proyecto
#    - tercer campo: costo (float)
# -------------------------------------------------------------------

def cargar_costos(nombre_archivo):
    G = nx.read_edgelist(
        nombre_archivo,
        delimiter=",",
        data=[("costo", float)]
    )
    return G


# -------------------------------------------------------------------
# MUESTRA el matching y su costo total.
# -------------------------------------------------------------------
def mostrar_matching(G, matching, consultores):
    costo_total = 0

    for c in consultores:
        p = matching[c]        # proyecto asignado
        costo = G[c][p]["costo"]
        print(c, "<->", p, "costo:", costo)
        costo_total = costo_total + costo

    print("Costo total mínimo:", costo_total)
    print("-" * 40)


# -------------------------------------------------------------------
# PROGRAMA PRINCIPAL
# -------------------------------------------------------------------
# COMPLETAR
