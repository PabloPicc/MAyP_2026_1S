import networkx as nx

# ------------------------------------------------------------
# Cargar el grafo ponderado desde nombre_archivo
# ------------------------------------------------------------
def cargar_rutas(nombre_archivo):
    """
    Carga un archivo CSV con líneas u,v,w donde w es un float.
    El grafo es no dirigido.
    """
    G = nx.read_edgelist(
        nombre_archivo,
        delimiter=",",
        data=[("tiempo_de_viaje", float)]
    )
    return G


# ------------------------------------------------------------
# Subgrafo restringido por umbral K
# ------------------------------------------------------------
def subgrafo_con_umbral(G, K):
    """
    Devuelve un subgrafo que conserva solo las aristas con peso <= K.
    """
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass


# ------------------------------------------------------------
# Cuerpo principal del programa.
# ------------------------------------------------------------
# COMPLETAR
