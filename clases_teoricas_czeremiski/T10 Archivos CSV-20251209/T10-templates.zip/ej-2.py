import csv

# Se abren los archivos fuente y destino de datos.
archivo_origen = open('provincias.csv', encoding='utf-8')
archivo_destino = open('provincias-reducido.csv', 'w', encoding='utf-8')

# Se crea el reader para el archivo provincias.csv.
reader = csv.DictReader(archivo_origen)

# Se crea el writer para el archivo provincias.csv.
campos_reducidos = #### COMPLETAR ACÁ ####
writer = csv.DictWriter(archivo_destino, fieldnames=campos_reducidos)
# Se escribe la primera línea de provincias-reducido.csv con los nombres de los campos.
writer.writeheader()

# Se hace un ciclo para obtener los datos de todas las provincias.
for d in reader:
  # Se leen los datos de interés de las provincias del archivo origen.
  prov_nombre = d['Provincia']
  prov_area = d['Área']
  prov_poblacion = d['PoblaciónProvincia']

  # Se crea el diccionario con los datos a escribir en el archivo destino.
  datos_prov_reducida = dict()
  #### COMPLETAR ACÁ ####

  # Se escriben los datos de la provincia actual.
  #### COMPLETAR ACÁ ####

# Finalmente se cierran ambos archivos
archivo_origen.close()
archivo_destino.close()
