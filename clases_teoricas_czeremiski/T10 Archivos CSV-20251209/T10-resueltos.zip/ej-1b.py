# Devuelve una lista con las nombres de las provincias que tienen más de 2 millones de habitantes.
def provincias_muy_populosas():
	archivo_provincias = open('provincias.csv', encoding='utf-8')

	# Se saltea la primera línea porque es el encabezado del archivo (sin datos)
	archivo_provincias.readline()

	# Se recorre de la línea 2 (primera con información de provincias)
	# en adelante para buscar provincias con más de 2 millones de habitantes.
	provincias_populosas = []
	for linea in archivo_provincias:
		 valores = linea.split(',')
		 pob_provincia = int(valores[3])
		 if pob_provincia > 2000000:
		     provincias_populosas.append(valores[0])

	# Se cierra el archivo
	archivo_provincias.close()
	
	return provincias_populosas
	

# Cuerpo principal del programa
print('Provincias con 2M+ de habitantes:')
provs_muy_pobladas = provincias_muy_populosas()
for prov in provs_muy_pobladas:
	print(prov)

