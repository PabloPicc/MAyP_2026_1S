# Función que evuelve la cantidad de habitantes de argentina de 
# acuerdo a la información contenida en el archivo 'provincias.csv'.
def poblacion_argentina():
	archivo_provincias = open('provincias.csv', encoding='utf-8')

	# Se saltea la primera línea porque es el encabezado del archivo (sin datos)
	archivo_provincias.readline()

	# Se recorre de la línea 2 (primera con información de provincias)
	# en adelante para calcular la población de Argentina
	pob_total = 0
	for linea in archivo_provincias:
		 valores = linea.split(',')
		 pob_provincia = int(valores[3])
		 pob_total = pob_total + pob_provincia
	
	# Se cierra el archivo
	archivo_provincias.close()	
	
	return pob_total


# Cuerpo principal del programa
print('Población de Argentina: ' + str(poblacion_argentina()) + ' habitantes.')


