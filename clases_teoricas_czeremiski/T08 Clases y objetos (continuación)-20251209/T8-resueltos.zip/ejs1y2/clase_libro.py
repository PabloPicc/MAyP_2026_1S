# Clase para representar libros
class Libro:

    # Constructor de objetos de tipo Libro
    def __init__(self, tit, aut, anio_pub):
        self.titulo = tit
        self.autor = aut
        self.anio_publicacion = anio_pub

    # Devuelve la representación como str de un libro
    def __repr__(self):
        return '(' + self.titulo + ';' + self.autor + ';' + str(self.anio_publicacion) + ')'
    
    # Dos libros son iguales si tienen el mismo título y el mismo autor
    def __eq__(self, other):
        return self.titulo == other.titulo and self.autor == other.autor
    
    # Un libro es menor que otro si fue publicado antes
    def __lt__(self, other):
        return self.anio_publicacion < other.anio_publicacion
    
    
