from clase_libro import Libro

libro = Libro("El Aleph", "Jorge Luis Borges", 1949)
print('Impresión de un libro:')
print(libro)

