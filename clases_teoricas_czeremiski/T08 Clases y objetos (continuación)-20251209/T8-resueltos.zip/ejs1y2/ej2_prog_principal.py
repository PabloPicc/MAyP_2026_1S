from clase_libro import Libro

aleph1 = Libro("El Aleph", "Jorge Luis Borges", 1949)
aleph2 = Libro("El Aleph", "Jorge Luis Borges", 1974)
boquitas = Libro("Boquitas pintadas", "Manuel Puig", 1969)
print(aleph1 == aleph2) 	
print(aleph1 == boquitas) 
	
libros = [aleph2, aleph1, boquitas]
print(libros)
libros.sort()
print(libros)

