# Clase para representar calzados
class Calzado:

    # Constructor de objetos de tipo Calzado
    def __init__(self, mar, mod, pre):
        self.marca = mar
        self.modelo = mod
        self.precio = pre

    # Devuelve el string para que Python imprima objetos de la clase
    def __repr__(self):
        # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
        pass
