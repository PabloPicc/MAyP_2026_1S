from clase_calzado import Calzado
from clase_carrito_compras import CarritoDeCompras

calzado1 = Calzado("Puma", "Borussia", 8699.99)
print('Impresión de un calzado:')
print(calzado1)

calzado2 = Calzado("Adidas", "New York", 7800.00)
calzado3 = Calzado("Topper", "Tenis", 5399.00)

carrito = CarritoDeCompras()
carrito.agregar(calzado1)
carrito.agregar(calzado2)
carrito.agregar(calzado3)

print()
print('Contenido del carrito:')
print(carrito)
