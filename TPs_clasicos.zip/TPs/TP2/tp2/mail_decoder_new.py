from auxiliares import se_cifra
import sys

def leer_mails(filename):
    ''' Abre el archivo filename y retorna una lista de strings, donde cada
    posicion contiene el contenido de un mail del archivo.'''
    nombre_archivo=filename
    archivo_handle=open(nombre_archivo,encoding="utf8")
    todos=archivo_handle.readlines()
    mails=[]
    for mensaje in todos:
        l1=archivo_handle.readline()
        SP=mensaje.split('\t')[1]
        mails.append(SP)
    archivo_handle.close()
    return mails

def ordenar_por_frecuencia(freq_dict):
    ''' Toma un diccionario de string en int y devuelve una lista de tuplas (string,int) con todos los 
    itmes del diccionario en orden decreciente por el value (int).'''
    #Primero se vuelca todo a una lista
    Tuplas=[]
    for key,contenido in freq_dict.items():
        Tuplas.append((key,contenido))
    #Luego se ordena i analiza la lista
    Tuplas_ordenadas=[]
    while len(Tuplas)>0:
        Valor1=Tuplas[0][1];spot=0
        for i in range(len(Tuplas)):
            if Tuplas[i][1]>Valor1:
                Valor1=Tuplas[i][1];spot=i
        Tuplas_ordenadas.append(Tuplas[spot])
        del Tuplas[spot]
    return Tuplas_ordenadas






def obtener_frecuencia_estatica():
    ''' Devuelve una lista con las frecuencias de caracteres, ya ordenados en forma decreciente.'''
    return ['e','t','a','o','i','n','s','h','r','d','l','c','u','m','w','f','g','y','p','b','v','k','j','x','q','z']

def obtener_frecuencia_caracteres(dataset):
    ''' Funcion que toma una lista de strings (con textos o emails) ydevuelve 
    un diccionario de (c,n), donde c es un caracter tal que se_cifra(c) = True 
    y n la cantidad de veces que aparece en todos los textos contenidos en dataset.'''

    #dataset=leer_mails(filename)
    diccionario={};char=[];i=1
    for mail in dataset:
        print('mail',i)
        i=i+1
        for chara in mail:
            if se_cifra(chara) and (chara in char):
                diccionario[chara]=diccionario[chara]+1
            elif se_cifra(chara) and (chara not in char):
                diccionario[chara]=1
                char.append(chara)
    return diccionario
    
def inferir_correspondencia(orden_cifrado, orden_sin_cifrar):
    ''' Funcion que toma dos listas de caracteres ordenados de forma decreciente y retorna una *correspondencia*.'''
    orden_cifrado_list=[];analogia={}
    for tupla in orden_cifrado:
        orden_cifrado_list.append(tupla[0])
    for i in range(len(orden_sin_cifrar)):
        analogia[orden_cifrado_list[i]]=orden_sin_cifrar[i]
    return analogia

def corregir_correspondencia(correspondencia):
    ''' Funcion que se utiliza para corregir manualmente la correspondencia inferida automaticamente
    por frecuencia.'''
    correspondencia['h']='f';correspondencia['g']='i'
    correspondencia['l']='n';correspondencia['s']='c'
    correspondencia['x']='l';correspondencia['n']='r'
    correspondencia['e']='p';correspondencia['j']='b'
    correspondencia['v']='h';correspondencia['m']='w'
    correspondencia['r']='y';correspondencia['p']='q'
    correspondencia['u']='z'

    return correspondencia

def descifrar_mensaje(mensaje, correspondencia):
    ''' Dado un mensaje (string) y una correspondencia (diccionario de string en string), reetorna el mensaje
    traducido utilizando la sustitucion dada por correspondencia.'''
    nuevo_mensaje=''
    for letra in mensaje:
        if se_cifra(letra):
            for key,contenido in correspondencia.items():
                if letra==key:
                    nuevo_mensaje=nuevo_mensaje+contenido
        else:
            nuevo_mensaje=nuevo_mensaje+letra
    return nuevo_mensaje

#Function que escribe traducciones
def traducir(mails,cifrado):
    ''' Abre el archivo filename y retorna una lista de strings, donde cada
    posicion contiene el contenido de un mail del archivo.'''
    nombre_archivo='mails_descifrados.txt'
    archivo_output=open(nombre_archivo,'w',encoding="utf8")
    i=1
    for mensaje in mails:
        print('mail N',i,'traducido')
        mens=descifrar_mensaje(mensaje, cifrado)
        archivo_output.write(mens)
        archivo_output.write('\n')
        i=i+1
    archivo_output.close()

def main():
        # Leer el archivo con los mails..
    nombre_archivo_mails = 'emails_cifrados.csv'
    emails_cifrados = leer_mails(nombre_archivo_mails)

    # Calculamos frecuencia para los mails y ordenamos de forma decreciente por cantidad de apariciones..
    freq_cifrado = obtener_frecuencia_caracteres(emails_cifrados)
    orden_cifrado = ordenar_por_frecuencia(freq_cifrado) 

    # Obtenemos lista ordenada de manera estatica, con obtener_frecuencia_estatica.
    orden_sin_cifrar = obtener_frecuencia_estatica()

    # Inferimos la correspondencia de manera automatica, con inferir_correspondencia.
    correspondencia_inf = inferir_correspondencia(orden_cifrado, orden_sin_cifrar)

    # Seguro la correspondencia tenga errores para modifiar. Elegimos un mensaje 
    # y vamos tratando de corregirla de manualmente.
    email = emails_cifrados[1]
    
    # Aplicamos una funcion para corregir aquellas correspondencias incorrectas.
    # Notar que no devuelve un valor, sino que modifica el parametro (ya que es
    # mutable).
    corregir_correspondencia(correspondencia_inf)
    # Desciframos el mensaje traducido, luego de inferrir (y corregir) la correspondencia.
    print(descifrar_mensaje(email, correspondencia_inf))


    # Finalmente, hacer una funcion que tome un nombre de archivo y guarde, de a uno por linea,
    # los mensajes descifrados.
    traducir(emails_cifrados,correspondencia_inf)

if __name__ == "__main__":
    main()
