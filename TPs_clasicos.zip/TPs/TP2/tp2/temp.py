import re
def leer_mails(filename):
    nombre_archivo=filename
    archivo_handle=open(nombre_archivo,encoding="utf8")
    todos=archivo_handle.readlines()
    Hay_info=True;mails=[]
    for mensaje in todos:
        l1=archivo_handle.readline()
        SP=mensaje.split('\t')[1]
        mails.append(SP)
    return mails

def se_cifra(caracter):
	""" Función que de tomar un único caracter y devuelve True
	si es lo que en el TP se considera cifrable y false en caso
	contrario, por ejemplo "se_cifra("(")" devuelve False y
	"se_cifra("z")" devuelve True. Debe usarse para identificar qué fue
	cifrado y qué no """
	return bool(re.compile("[a-z]").match(caracter))


def obtener_frecuencia_caracteres(dataset):
    ''' Funcion que toma una lista de strings (con textos o emails) ydevuelve 
    un diccionario de (c,n), donde c es un caracter tal que se_cifra(c) = True 
    y n la cantidad de veces que aparece en todos los textos contenidos en dataset.'''

    #dataset=leer_mails(filename)
    diccionario={};char=[];i=1
    for mail in dataset:
        print('mail',i)
        i=i+1
        for chara in mail:
            if se_cifra(chara) and (chara in char):
                diccionario[chara]=diccionario[chara]+1
            elif se_cifra(chara) and (chara not in char):
                diccionario[chara]=1
                char.append(chara)
    return diccionario





def main():
    filename = 'emails_cifrados.csv'
    emails_cifrados=leer_mails(filename)
    G=obtener_frecuencia_caracteres(emails_cifrados)

    
if __name__ == "__main__":
    main()
    

    