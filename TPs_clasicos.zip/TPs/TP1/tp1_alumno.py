def contar_pares(l):
	i=0;count=0
	while i<=len(l)-1:
		num=l[i]
		if (num%2==0):
			count=count+1
		i=i+1
	return count



def posicion_minimo_lista(l):
	i=1;mini=l[0];mini_pos=0
	while i<=len(l)-1:
		if l[i]<mini:
			mini=l[i]
			mini_pos=i
		i=i+1
	return mini_pos



def reverso(l):
	reversa=[];i=len(l)-1
	while i>=0:
		reversa.append(l[i])
		i=i-1
	return reversa



def es_capicua(l):
	if l[0]==l[len(l)-1]:
		es_capicua=True
	else:
		es_capicua=False
	return es_capicua



def es_capicua2(l):
	L=reverso(l)
	if L[0]==l[0]:
		es_capicua=True
	else:
		es_capicua=False
	return es_capicua



def concatenar(l1,l2):
	i=0;L=l1[0:len(l1)]
	while i<=len(l2)-1:
		L.append(l2[i])
		i=i+1
	return L



def quitar_apariciones(l,elem):
	i=0
	while i<=len(l)-1:
		if l[i]==elem:
			del l[i]
			i=0
		else:
			i=i+1
	return l

def es_primo(n):
  j=0
  for num in list(range(2,n)):
    if n%num==0:
      j=j+1
  if j==0:
      return 'Es primo'
  else:
      return 'No es primo'	

def primos_hasta(n):
	i=2;primos=[]
	while i<=n:
		prueba=es_primo(i)
		if prueba=='Es primo':
			primos.append(i)
		i=i+1
	return primos







def main():
	a = 1
	b = 10
	c = 20
	l1 = [1,2,3]
	l2 = [4,5,6]
	l3 = ['a','b','b','a']
	l4 = [6,2,3,16,9,3,13,4,1]
	elem = 5
	n = 10 

	# test contar_pares
	#print('contar_pares: ', contar_pares(l1))
	#print('contar_pares: ', contar_pares(l2))

	# test posicion minimo lista
	#print('posicion_minimo_lista: ', posicion_minimo_lista(l1))
	#print('posicion_minimo_lista: ', posicion_minimo_lista(l4))

	# test reverso
	#print('reverso: ', reverso(l1))
	#print('reverso: ', reverso(l2))
	#print('reverso: ', reverso(l3))

	# test es_capicua
	#print('es_capicua(l1): ', es_capicua(l1))
	#print('es_capicua(l2): ', es_capicua(l2))
	#print('es_capicua(l3): ', es_capicua(l3))
	#print('es_capicua(l1): ', es_capicua2(l1))
	#print('es_capicua(l2): ', es_capicua2(l2))
	#print('es_capicua(l3): ', es_capicua2(l3))

	# test concatenar
	#print('concatenar: ', concatenar(l1,l2))
	#print('l1 es: ', l1)
	#print('l2 es: ', l2)

	# test quitar_apariciones
	#quitar_apariciones(l3,'b')
	#print('sin aparciones: ', l3)

	# test primo_hasta
	print('primo_hasta', primos_hasta(100))

	

if __name__ == '__main__':
	main()
