def contar_pares(l):
	pass

def posicion_minimo_lista(l):
	pass

def reverso(l):
	pass

def es_capicua(l):
	pass

def concatenar(l1,l2):
	pass

def quitar_apariciones(l,elem):
	pass

def primos_hasta(n):
	pass

def main():
	a = 1
	b = 10
	c = 20
	l1 = [1,2,3]
	l2 = [4,5,6]
	l3 = ['a','b','b','a']
	l4 = [6,2,3,16,9,3,13,4,1]
	elem = 5
	n = 10 

	# test contar_pares
	# print('contar_pares: ', contar_pares(l1))
	# print('contar_pares: ', contar_pares(l2))

	# test posicion minimo lista
	# print('posicion_minimo_lista: ', posicion_minimo_lista(l1))
	# print('posicion_minimo_lista: ', posicion_minimo_lista(l4))

	# test reverso
	# print('reverso: ', reverso(l1))
	# print('reverso: ', reverso(l2))
	# print('reverso: ', reverso(l3))

	# test es_capicua
	# print('es_capicua(l1): ', es_capicua(l1))
	# print('es_capicua(l2): ', es_capicua(l2))
	# print('es_capicua(l3): ', es_capicua(l3))

	# test concatenar
	# print('concatenar: ', concatenar(l1,l2))

	# test quitar_apariciones
	# quitar_apariciones(l3,'b')
	# print('sin aparciones: ', l3)

	# test primo_hasta
	# print('primo_hasta', primos_hasta(n))

	

if __name__ == '__main__':
	main()
