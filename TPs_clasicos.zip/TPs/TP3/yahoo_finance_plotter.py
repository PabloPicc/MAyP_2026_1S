import datetime
from dateutil import tz
import urllib.request
import json
import sys
import matplotlib.pyplot as plt


############################# FUNCIONES AUXILIARES DEFINIDAS POR EL GRUPO ############################### 

def get_quote_json(q, init_date, end_date, interval):
    '''Accede a la API de Yahoo! Finance para la accion "q", con la fecha de inciio, fin, e intervalo correspondiente
    y devuelve el JSON (dict) correspondiente.'''
    URL_static= 'https://query2.finance.yahoo.com/v8/finance/chart/'
    Init_timestamp=to_date(init_date);End_timestamp=to_date(end_date)
    Init_posix=str(int(to_posix_timestamp(Init_timestamp)))
    End_posix=str(int(to_posix_timestamp(End_timestamp)))
    #La URL total
    URL=URL_static+q+'?period1='+Init_posix+'&period2='+End_posix+'&interval='+interval+'&events=history'
    #Los pasos de autenticación
    req = urllib.request.Request(URL)
    r = urllib.request.urlopen(req).read()
    result = json.loads(r.decode('utf-8')) 
    return result

def dias_positivos(fecha,rendimiento):
    max_dias=0;max_fechas=[];suma=0;sec_fechas=[]
    for i in range(len(rendimiento)):
        if rendimiento[i]>=0:
            suma=suma+1
            sec_fechas.append(fecha[i])
        else:
            if suma>max_dias:
                max_dias=suma;max_fechas=sec_fechas
                suma=0;sec_fechas=[]
            else:
                suma=0;sec_fechas=[]
    fecha1=max_fechas[0]
    fecha2=max_fechas[len(max_fechas)-1]
    #fecha1=to_date(fecha1);fecha2=to_date(fecha2)
    #Dias=fecha2-fecha
    #return Dias.days
    return (fecha1,fecha2)

def dias_negativos(fecha,rendimiento):
    max_dias=0;max_fechas=[];suma=0;sec_fechas=[]
    for i in range(len(rendimiento)):
        if rendimiento[i]<0:
            suma=suma+1
            sec_fechas.append(fecha[i])
        else:
            if suma>max_dias:
                max_dias=suma;max_fechas=sec_fechas
                suma=0;sec_fechas=[]
            else:
                suma=0;sec_fechas=[]
    fecha1=max_fechas[0]
    fecha2=max_fechas[len(max_fechas)-1]
    #fecha1=to_date(fecha1);fecha2=to_date(fecha2)
    #Dias=fecha2-fecha
    #return Dias.days
    return (fecha1,fecha2)

#Se puede encarar con el asunto de las sublistas en el tema matrices
def maximo_rendimiento_obtenible(fecha,precios):
    max_ren=(precios[1]/precios[0])-1
    Fechas=(fecha[1],fecha[0])
    for i in range(len(precios)):
        for j in range(i,len(precios)):
            ren=(precios[j]/precios[i])-1
            if ren>max_ren:
                max_ren=ren
                Fechas=(fecha[j],fecha[i])
    #Cantidad de días
    fecha1=to_date(Fechas[1]);fecha2=to_date(Fechas[0])
    Dias=(fecha2-fecha1).days
    #Lista con tupla de precios, tupla de días y cantidad de días
    ret=[max_ren,Fechas,Dias]
    return ret

def minimo_rendimiento_obtenible(fecha,precios):
    max_ren=(precios[1]/precios[0])-1
    Fechas=(fecha[1],fecha[0])
    for i in range(len(precios)):
        for j in range(i,len(precios)):
            ren=(precios[j]/precios[i])-1
            if ren<max_ren:
                max_ren=ren
                Fechas=(fecha[j],fecha[i])
    #Cantidad de días
    fecha1=to_date(Fechas[1]);fecha2=to_date(Fechas[0])
    Dias=(fecha2-fecha1).days
    #Lista con tupla de precios, tupla de días y cantidad de días
    ret=[max_ren,Fechas,Dias]
    return ret



############################# FUNCIONES AUXILIARES DEFINIDAS POR LA CATEDRA ############################### 
def to_date(strdate):
    '''toma un string en formato %Y-%m-%d y lo convierte a algo de tipo fecha'''
    return datetime.datetime.strptime(strdate, '%Y-%m-%d')

def to_ymd(ts):
    ''' Toma un timestamp y lo convierte a un string con formato %Y-%m-%d'''
    return datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')

def to_posix_timestamp(date):
    '''Toma un datetime y lo convierte a timestamp formato POSIX'''
    return (date - datetime.datetime.utcfromtimestamp(0)).total_seconds() + 14400


############################# FUNCION PRINCIPAL ############################### 
def main():
    ''' Es la funcion principal donde se ejecuta nuestro programa.'''

    # Leemos el archivo input.cfg con los parametros para la ejecucion.
    file=open('input.cfg')
    param_crudos=file.readlines();param=[]
    for i in range(len(param_crudos)-1):
        elem=param_crudos[i].split('\n')[0]
        param.append(elem)
    param.append(param_crudos[len(param_crudos)-1])

    print(param)



    # Recordar que las fechas estan en formato yyyy-mm-dd
    # Recordar que los posibles valores para el intevalo son los siguientes:
    # ["1d","5d","1wk","1mo","3mo","6mo","1y","2y","5y","10y","ytd","max"]

    # Obtenemos las fechas de inicio y fin, el intervalo, y las acciones a analizar.
    # Las guardamos en quotes.
    init_date=param[0];end_date=param[1];interval=param[2]
    quotes = param[3:6]

    Acciones_info={}

    for q in quotes:
        # Obtenemos el JSON.
        DATA=get_quote_json(q, init_date, end_date, interval)
        Acciones_info[q]={}

        # Extraemos y procesamos la informacion.
        fechas_crudas=DATA['chart']['result'][0]['timestamp']
        fechas_limpias=[]
        for i in range(len(fechas_crudas)):
            fech=to_ymd(fechas_crudas[i])
            fechas_limpias.append(fech)
        precios_close=DATA['chart']['result'][0]['indicators']['adjclose'][0]['adjclose']
        precios_Low=DATA['chart']['result'][0]['indicators']['quote'][0]['low']
        precios_High=DATA['chart']['result'][0]['indicators']['quote'][0]['high']
        precios_Medium=[]
        for i in range(len(precios_Low)):
            med=(precios_High[i]+precios_Low[i])/2
            precios_Medium.append(med)

        #Parece que si o si hay que sacar los rendimientos
        r=[]
        for i in range(len(precios_close)-1):
            ren=(precios_close[i+1]/precios_close[i])-1
            r.append(ren)
        fecha_r=fechas_limpias[1:len(fechas_limpias)]

        Acciones_info[q]['fecha']=fechas_limpias
        Acciones_info[q]['precio_close']=precios_close
        Acciones_info[q]['precio_high']=precios_High
        Acciones_info[q]['precio_low']=precios_Low
        Acciones_info[q]['precio_medium']=precios_Medium
        Acciones_info[q]['rendimientos']=r
        Acciones_info[q]['fecha_r']=fecha_r

        # Agregamos el grafico de la serie.
        plt.plot(fechas_limpias,precios_close,'-o')
        plt.plot(fechas_limpias,precios_Medium,'-x')
        # Agregamos la leyenda al grafico.
        plt.legend(['close','medium'])
        # Hacemos show del grafico.
        plt.show()

        # Calculamos las metricas
        Acciones_info[q]['max_racha_positiva']=dias_positivos(fecha_r,r)
        Acciones_info[q]['max_racha_negativa']=dias_negativos(fecha_r,r)
        Acciones_info[q]['max_rendimiento_fventafcompra_dias']=maximo_rendimiento_obtenible(fechas_limpias,precios_close)
        Acciones_info[q]['min_rendimiento_fventafcompra_dias']=minimo_rendimiento_obtenible(fechas_limpias,precios_close)

        

if __name__ == '__main__':
    main()

