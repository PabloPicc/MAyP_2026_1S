import networkx as nx
import random

# TO-DO: completar en función de la representacion asumida para los nodos del grafo (tuplas o string)
BEG = ('__beg__','__beg__')
END = ('__end__','__end__')

def get_next_word(bot, v):
	r = random.random()
	acum = 0.0

	for w in bot.successors(v):
		acum = acum + bot[v][w]['prob']
		if r <= acum:
			return w


def simulate_tweet(bot):
	word = BEG
	ret = word[1]

	# Completar la simulacion. Debe terminar cuando la ultima palabra agregada es END
	while word!=END:
		word=get_next_word(bot,word)
		ret=ret+' '+word[1]
		

	# Retornar el tweet generado.
	return ret

def main():

	# input user
	username = 'realDonaldTrump'
	graph_file = username + '.gml'

	# read the digraph
	#bot = nx.read_gml(graph_file)
	bot = nx.read_gpickle(graph_file)

	# simulate tweet
	tweet = simulate_tweet(bot)
	print(tweet)

if __name__ == '__main__':
	main()
