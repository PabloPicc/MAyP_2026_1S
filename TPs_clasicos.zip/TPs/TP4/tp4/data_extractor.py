import json

def extract_tweets(input_file,output_file):
    #Se abre el archivo
    handle=open(input_file,encoding='utf-8')
    #Se abre un archivo donde se volcarán los tweets
    handle2=open(output_file,'w')
    #linea a linea se lee, se filtra lo que no es un retweet, se extrae el tweet
    #y se escribe en una línea del archivo output
    Tweets_crudos=handle.readlines()
    for tweet in Tweets_crudos:
        tweet_dic=json.loads(tweet)
        if tweet_dic['retweet']==False:
            handle2.write(tweet_dic['tweet'])
            handle2.write('\n')
    handle.close()
    handle2.close()

def main():

	# input user
	username = 'realDonaldTrump'
	filename = username + '.data'

	# Extract tweets from raw data
	tweets_filename = username + '.tweets.txt'
	extract_tweets_text(filename, tweets_filename)


if __name__ == '__main__':
	main()