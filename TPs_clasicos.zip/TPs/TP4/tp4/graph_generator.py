from nltk.tokenize import TweetTokenizer
import pickle
import networkx as nx
import random
import matplotlib.pyplot as plt

BEG = '__beg__ __beg__'
END = '__end__ __end__'

def process_tweets(tweets_filename):
    handle=open(tweets_filename)
    lectura=handle.readlines()
    handle.close()
    RES=[]
    for tweet in lectura:
        tkn=TweetTokenizer()
        begend=BEG+' '+tweet+' '+END
        #tokens.append(begend)
        tokens=tkn.tokenize(begend)
        tokens_tupla=[]
        for i in range(len(tokens)-1):
            tupla=(tokens[i],tokens[i+1])
            tokens_tupla.append(tupla)
        RES.append(tokens_tupla)
    return RES

def add_text_to_digraph(text, D):
	# Agrega un determinado texto tokenizado al grafo, actualizando correctamente los pesos del mismo.
	# Notar que algunos ejes ya podrian estar definidos de tweets anteriores.
	# Los pesos deben ser la cantidad de apariciones del correspondiente eje (bigrama)
	# Los cambios se aplican directamente sobre D.
	
	#Se ingresa una lista de tuplas, se la recorre y se va agregando el eje
	#Si el eje ya existe, se le suma una unidad en el peso
	for i in range(len(text)-1):
		if (text[i],text[i+1]) in D.edges:
			D[text[i]][text[i+1]]['weight']=D[text[i]][text[i+1]]['weight']+1
		else:
			D.add_edge(text[i],text[i+1],weight=1)


def generate_graph(tknzd_text):
	# Funcion general encargada de armar la primera version del grafo.
	# Llama a la funcion auxiliar add_text_to_digraph.
	D=nx.DiGraph()
	for tweet in tknzd_text:
		add_text_to_digraph(tweet, D)
	return D


def adjust_out_edges_weight(D,v):
	# Funcion que se encarga de convertir los pesos de los ejes salientes de v en frecuencias.
	# Trabaja directamente sobre el grafo D.
	Nodo=dict(D[v]);suma=0
	#Primero la suma
	for nodo in Nodo.keys():
		suma=suma+Nodo[nodo]['weight']
	#Luego el prom
	for nodo in Nodo.keys():
		Nodo[nodo]['prob']=Nodo[nodo]['weight']/suma
			

def calculate_markov_chain(D):
	for v in D.nodes:
		adjust_out_edges_weight(D,v)

def main():

	# input user
	username = 'realDonaldTrump'
	tweets_filename = username + '.tweets.txt'

	# Process tweets
	tknzd_text = process_tweets(tweets_filename)

	# Generate weighted graph
	D = generate_graph(tknzd_text)
	
	# Convert edges weights to probabilities.
	calculate_markov_chain(D)

	# Some debug info
	print('Graph statistics:', D.number_of_nodes(), D.number_of_edges())

	# persist the digraph.
	graph_file = username + '.gml'
	#nx.write_gml(D, graph_file)
	# si se utilizan tuplas como nodos, usar la siguiente linea
	# actualizar convenientemente en bot.py
	nx.write_gpickle(D, graph_file)

if __name__ == '__main__':
	main()