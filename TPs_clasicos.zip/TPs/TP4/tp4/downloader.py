import twint


def download(username, output, limit):
	# Configure
	c = twint.Config()
	c.Username = username
	c.Store_json = True
	c.Output = output
	c.Retweets = True
	c.Limit = limit

	# Run
	twint.run.Profile(c)

def main():

	# input user
	username = 'JMilei'

	# structure of the files and maximum number of downloads
	filename = username + '.data'
	limit = 100

	# Download raw data
	download(username, filename, limit)


if __name__ == '__main__':
	main()