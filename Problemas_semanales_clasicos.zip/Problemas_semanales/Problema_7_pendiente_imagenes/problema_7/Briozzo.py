import matplotlib.pyplot as plt
import matplotlib.image as mpimg

def to_grayscale2(img, m, n):
	matriz_nueva = []
	matriz_nueva_aux = []
	#red = 0
	#green = 0
	#blue = 0
	promedio = 0
	for i in range(m):
		for j in range(n):
			#red = img[i][j][0]
			#green = img[i][j][1]
			#blue = img[i][j][2]
			promedio = (img[i][j][0] + img[i][j][1] + img[i][j][2]) / 3
			matriz_nueva_aux.append(int(promedio))
		matriz_nueva.append(matriz_nueva_aux)
	return matriz_nueva

#Por alguna razon no me corre el codigo, pero lo revise con Tobias y me pidio que se lo mande.


def main():
	
	# Leemos la imagen
	filename = '4.2.03.tiff'
	img = mpimg.imread(filename)
	# obtenemos m = filas, n = column, ch = cantida de canales (3)
	m, n, ch = img.shape



	# Mostramos la imagen original (en colores)
	plt.imshow(img)
	plt.show()

	# imprimimos pixel 0,0 original
	#print(img[10][0])


	# convertimos a escala de grises.
	image_grayscale2 = to_grayscale2(img, m, n)

	# imprimimos pixel 0,0 escala de grises
	#rint(image_grayscale[0][0])

	# mostramos la nueva imagen.
	plt.imshow(image_grayscale2, cmap = 'gray')
	plt.show()


if __name__ == '__main__':
	main()