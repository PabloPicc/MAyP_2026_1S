import matplotlib.pyplot as plt
import matplotlib.image as mpimg

def to_grayscale(img, m, n):
    ret = []
    for i in range(m):
        aux = []
        for j in range(n):
            aux.append(round((sum(img[i][j])/3.0)))
        ret.append(aux)
    return ret

def main():
	
	# Leemos la imagen
	filename = '4.2.03.tiff'
	img = mpimg.imread(filename)
	# obtenemos m = filas, n = column, ch = cantida de canales (3)
	m, n, ch = img.shape

	# Mostramos la imagen original (en colores)
	plt.imshow(img)
	plt.show()

	# imprimimos pixel 0,0 original
	print(img[0][0])

	# convertimos a escala de grises.
	image_grayscale = to_grayscale(img, m, n)

	# imprimimos pixel 0,0 escala de grises
	print(image_grayscale[0][0])

	# mostramos la nueva imagen.
	plt.imshow(image_grayscale, cmap = 'gray')
	plt.show()


if __name__ == '__main__':
	main()