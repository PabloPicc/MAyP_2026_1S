def calculo_limites(n1,n2,n3,n4):
    prom=(n1+n2+n3+n4)/4
    inf=prom*0.98;sup=prom*1.02
    print('El limite inferior es ', inf)
    print('El limite superior es ', sup)
    return inf





def main():

    a = (39.8 + 40.1 + 40.5 + 40.4)/4
    print("limite inferior", 0.98*a)
    print("limite superior", 1.02*a)

    a = (59.6 + 57.4 + 58.1 + 60.1)/4
    print("limite inferior", 0.98*a)
    print("limite superior", 1.02*a)

    a = (45.3 + 45.9 + 46.3 + 46.3)/4
    print("limite inferior", 0.98*a)
    print("limite superior", 1.02*a)

    a = (100.1 + 101.2 + 100.5 + 101.3)/4
    print("limite inferior", 0.98*a)
    print("limite superior", 1.02*a)

    a = (15.8 + 16.9 + 14.1 + 13.9)/4
    print("limite inferior", 0.98*a)
    print("limite superior", 1.02*a)
    print(' ')
    print('Prueba 1')
    calculo_limites(39.8,40.1,40.5,40.4)
    calculo_limites(59.6 , 57.4 , 58.1 , 60.1)
    calculo_limites(45.3 , 45.9 , 46.3 , 46.3)
    calculo_limites(100.1 , 101.2 , 100.5 , 101.3)
    calculo_limites(15.8 , 16.9 , 14.1 , 13.9)



if __name__ == "__main__":
    main()