def hamming_distance(s1,s2):
    ''' Recordar que pueden asumir que vale que len(s1) == len(s2).'''
    list_s1=list(s1);list_s2=list(s2);count=0
    for i in range(len(s1)):
        if list_s1[i]!=list_s2[i]:
            count=count+1
    return count

def suma_hamming_distance(s1,s2):
    ''' Recordar que pueden asumir que vale que len(s1) <= len(s2).'''
    list_s1=list(s1);list_s2=list(s2);count=0
    largo1=len(s1)
    for i in range((len(s2)-largo1+1)):
        j=i+largo1
        sub=list_s2[i:j]
        count=count+hamming_distance(sub,list_s1)
    return count








def main():

    # Ejemplos hamming_distance
    print(hamming_distance('homero', 'Hoemro'))
    print(hamming_distance('homero', 'aaaaaa'))
    print(hamming_distance('homero', 'homero'))

    # Ejemplos suma_hamming_distance

    print(suma_hamming_distance('homero', 'Hoemro'))
    print(suma_hamming_distance('oee', 'Hoemro'))
    print(suma_hamming_distance('01', '00111'))


if __name__ == "__main__":
    main()