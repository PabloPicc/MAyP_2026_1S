import random
import pprint
import networkx as nx
import matplotlib.pyplot as plt


def generar_digrafo_unigramas(tokens):

    # constuir el grafo que representa un camino uniendo el elemento i con el i+1
    D = nx.DiGraph()
    for i in range(len(tokens)):
        D.add_node(tokens[i])
        if i>0:
            D.add_edge(tokens[i-1],tokens[i])
    nx.draw(D, with_labels=True)
    plt.show()
    return D

def generar_digrafo_bigramas(tokens):
    dupla_tokens=[]
    for i in range(len(tokens)-1):
        dupla_tokens.append((tokens[i],tokens[i+1]))

    D=generar_digrafo_unigramas(dupla_tokens)

    return D


def main():

    tokens =  ['He' , 'walks' , 'down' , 'eerie' , 'roads' , '.']

    D1 = generar_digrafo_unigramas(tokens)

    D2 = generar_digrafo_bigramas(tokens)


if __name__ == "__main__":
    main()