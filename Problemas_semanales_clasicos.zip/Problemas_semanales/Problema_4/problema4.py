def update_values(values):
    for i in range(len(values)):
        values[i] = 2*values[i]

def duplicacion_dinamica(l,values, k):
    ''' l lista de enteros, values lista de enteros, k entero'''

    for elem in l:
        print(elem, k, values)
        if elem in values:
            k = 2*k
            update_values(values)

    return k
    

def main():

    l = [1,3,2,10,4,8,12,13]
    values = [3, 2]
    k = 3
    print(duplicacion_dinamica(l, values, k))


if __name__ == "__main__":
    main()