import random
import pprint

def best_improving_position(A, m, n, row, col):
    #Confirmo que el punto es válido
    if row>m-1 or col>n-1 or m<1 or n<1:
        print('Punto inválido')
        return None
    #Veo donde estoy parado
    point=A[row][col]
    mini=point
    #Recorro la matriz entera con otros contadores y saco los vecinos
    for ii in range(m):
        for jj in range(m):
            disti=abs(row-ii);distj=abs(col-jj)
            if disti<=1 and distj<=1 and (disti+distj)>0 and A[ii][jj]<mini:
                mini=A[ii][jj]
                Tupla=(ii,jj)
    if mini==point:
        Tupla=None
    return Tupla




def steepest_descent(A, m, n, i, j):
    Tupla=best_improving_position(A, m, n, i, j)
    while Tupla!=None:
        Tupla=best_improving_position(A, m, n, Tupla[0], Tupla[1])
        if Tupla!=None:
            Tupla_resp=(Tupla[0],Tupla[1])
    return Tupla_resp




def create_random_matrix(m, n):
    random.seed(10)
    A = []
    # construimos la matriz randomizada
    # Por como se construye, salvo por un poco de ruido, los valores
    # los valores tienden a ser crecientes con i y j.
    for i in range(m):
        aux = []
        for j in range(n):
            aux.append(i*n + j + (-5 + int(random.random()*10)))

        A.append(aux)

    return A

def main():

    m = 6
    n = 6
    
    A = create_random_matrix(m, n)

    print(A)
    # Asumiendo que la matriz random es la del enunciado (que podria no serlo), replicamos la corrida.
    print(steepest_descent(A, m, n, 4, 1))


if __name__ == "__main__":
    main()