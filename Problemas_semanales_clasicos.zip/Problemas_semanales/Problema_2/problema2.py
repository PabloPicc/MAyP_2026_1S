#YOOOO
def suma_alternada(n):
    if n==0:
        return 0
    elif n==1:
        return 1
    else:
        return n+suma_alternada(n-2)

def suma_alternada_par(n):
    if n%2==0:
        return suma_alternada(n)
    else:
        n=n-1
        return suma_alternada(n)

def main():

    print(suma_alternada(5))
    print(suma_alternada(8))
    print(suma_alternada(15))

    print(suma_alternada_par(5))
    print(suma_alternada_par(8))
    print(suma_alternada_par(15))

if __name__ == "__main__":
    main()