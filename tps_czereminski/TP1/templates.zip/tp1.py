from detector_fraudes import multiplo_de_mil, suma_de_digitos_menor_que_diez, \
                   extremos_iguales, es_sospechoso, filtrar_sospechosos, \
                   suma_de_sospechosos

def elegir_funcion():
    '''
    Despliega el menú de funciones disponibles en la pantalla y devuelve la
    opción elegida por el usuario. La opción elegida por el usuario, en
    mayúscula y sin espacios adelante y atrás según la siguiente codificación:
        A -> ¿Múltiplo de 1000? [m]
        B -> Suma de dígitos [m]
        C -> ¿Extremos iguales? [m]
        D -> ¿Es sospechoso? [m]
        E -> Filtrar sospechosos [ms]
        F -> Suma de sospechosos [ms]
        G -> Finalizar
    '''
    print()
    print('Funciones disponibles')
    print('---------------------')
    print('A. ¿Múltiplo de 1000? [m]')
    print('B. ¿Suma de dígitos menor que 10? [m]')
    print('C. ¿Extremos iguales? [m]')
    print('D. ¿Es sospechoso? [m]')
    print('E. Filtrar sospechosos [ms]')
    print('F. Suma de sospechosos [ms]')
    print('G. Finalizar')
    opcion_elegida = input('Seleccione una opción: ').upper().strip()
    return opcion_elegida


# Cuerpo principal del programa.
finalizar = False
while not finalizar:
    opcion_seleccionada = elegir_funcion()
    # Se analiza la opción elegida.
    if opcion_seleccionada == 'A':
        m = input('Ingrese m: ')
        # [COMPLETAR]
    elif opcion_seleccionada == 'B':
        m = input('Ingrese m: ')
        # [COMPLETAR]
    elif opcion_seleccionada == 'C':
        m = input('Ingrese m: ')
        # [COMPLETAR]
    elif opcion_seleccionada == 'D':
        m = input('Ingrese m: ')
        # [COMPLETAR]
    elif opcion_seleccionada == 'E':
        ms = input('Ingrese ms: ')
        # [COMPLETAR]
    elif opcion_seleccionada == 'F':
        ms = input('Ingrese ms: ')
        # [COMPLETAR]
    elif opcion_seleccionada == 'G':
        finalizar = True
    else:
        print('Opción inválida.')

    if opcion_seleccionada != 'G':
        input('Presione ENTER para continuar.')
