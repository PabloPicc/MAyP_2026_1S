def multiplo_de_mil(m):
    ''' Devuelve True si el monto m (int) es múltiplo de mil y False en caso contrario. '''
    # [COMPLETAR]

def suma_de_digitos_menor_que_diez(m):
    ''' Devuelve True si la suma de los dígitos de m (int) es menor que 10 y False en caso contrario. '''
    # [COMPLETAR]

def extremos_iguales(m):
    '''
    Devuelve True si el primer dígito del monto m (int) es igual
    al último dígito de m distinto de cero y False en caso contrario.
    '''
    # [COMPLETAR]

def es_sospechoso(m):
    ''' Devuelve True si el monto m (int) es sospechoso y False en caso contrario. '''
    # [COMPLETAR]

def filtrar_sospechosos(ms):
    ''' Devuelve una lista con los montos sospechosos de ms (lista de ints). '''
    # [COMPLETAR]

def suma_de_sospechosos(ms):
    ''' Devuelve la suma (int) de los montos sospechosos de ms (lista de ints). '''
    # [COMPLETAR]
