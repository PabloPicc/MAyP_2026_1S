from detector_fraudes import multiplo_de_mil, suma_de_digitos_menor_que_diez, \
                   extremos_iguales, es_sospechoso, filtrar_sospechosos, \
                   suma_de_sospechosos

######################### Funciones auxiliares #########################
def convertir_a_ints(xs):
    '''
    Dada una lista de strings formados únicamente por dígitos,
    devuelve una lista con los enteros correspondientes.
    '''
    res = []
    for x in xs:
        res.append(int(x))
    return res

def convertir_a_strings(xs):
    '''
    Dada una lista de enteros (ints),
    devuelve una lista con sus representaciones como strings.
    '''
    res = []
    for x in xs:
        res.append(str(x))
    return res
#########################################################################


def elegir_funcion():
    '''
    Despliega el menú de funciones disponibles en la pantalla y devuelve la
    opción elegida por el usuario. La opción elegida por el usuario, en
    mayúscula y sin espacios adelante y atrás según la siguiente codificación:
        A -> ¿Múltiplo de 1000? [m]
        B -> Suma de dígitos [m]
        C -> ¿Extremos iguales? [m]
        D -> ¿Es sospechoso? [m]
        E -> Filtrar sospechosos [ms]
        F -> Suma de sospechosos [ms]
        G -> Finalizar
    '''
    print()
    print('Funciones disponibles')
    print('---------------------')
    print('A. ¿Múltiplo de 1000? [m]')
    print('B. ¿Suma de dígitos menor que 10? [m]')
    print('C. ¿Extremos iguales? [m]')
    print('D. ¿Es sospechoso? [m]')
    print('E. Filtrar sospechosos [ms]')
    print('F. Suma de sospechosos [ms]')
    print('G. Finalizar')
    opcion_elegida = input('Seleccione una opción: ').upper().strip()
    return opcion_elegida


# Cuerpo principal del programa.
finalizar = False
while not finalizar:
    opcion_seleccionada = elegir_funcion()
    # Se analiza la opción elegida.
    if opcion_seleccionada == 'A':
        m = input('Ingrese m: ')
        if multiplo_de_mil(int(m)):
            print(m + ' es múltiplo de 1000.')
        else:
            print(m + ' no es múltiplo de 1000.')
    elif opcion_seleccionada == 'B':
        m = input('Ingrese m: ')
        if suma_de_digitos_menor_que_diez(int(m)):
            print('La suma de los dígitos de ' + str(m) + ' es menor que 10.')
        else:
            print('La suma de los dígitos de ' + str(m) + ' no es menor que 10.')
    elif opcion_seleccionada == 'C':
        m = input('Ingrese m: ')
        if extremos_iguales(int(m)):
            print('Los extremos de ' + m + ' son iguales.')
        else:
            print('Los extremos de ' + m + ' no son iguales.')
    elif opcion_seleccionada == 'D':
        m = input('Ingrese m: ')
        if es_sospechoso(int(m)):
            print(m + ' es un monto sospechoso.')
        else:
            print(m + ' no es un monto sospechoso.')
    elif opcion_seleccionada == 'E':
        ms_str = input('Ingrese ms: ').split(',')
        ms_int = convertir_a_ints(ms_str)
        sospechosos = filtrar_sospechosos(ms_int)
        if len(sospechosos) == 0:
            print('No se ingresaron montos sospechosos.')
        else:
            print('Monto(s) sospechoso(s): ' + ','.join(convertir_a_strings(sospechosos)))
    elif opcion_seleccionada == 'F':
        ms_str = input('Ingrese ms: ').split(',')
        ms_int = convertir_a_ints(ms_str)
        suma = suma_de_sospechosos(ms_int)
        print('La suma de montos sospechosos es ' + str(suma) + '.')
    elif opcion_seleccionada == 'G':
        finalizar = True
    else:
        print('Opción inválida.')

    if opcion_seleccionada != 'G':
        input('Presione ENTER para continuar.')
