def multiplo_de_mil(m):
    ''' Determina si el monto m es múltiplo de mil.'''
    return m%1000 == 0

def suma_de_digitos_menor_que_diez(m):
    ''' Determina si la suma de los dígitos de m es menor que 10. '''
    suma = 0
    m_str = str(m)
    for dig_str in m_str:
        suma = suma + int(dig_str)
    return suma < 10

def extremos_iguales(m):
    '''
    Determina si el primer dígito del monto m es igual al último dígito de m distinto de cero.
    '''
    return int(str(m)[0]) == ultimo_digito_distinto_de_cero(m)

def es_sospechoso(m):
    ''' Determina si el monto m es sospechoso. '''
    return multiplo_de_mil(m) and suma_de_digitos_menor_que_diez(m) and extremos_iguales(m)

def filtrar_sospechosos(ms):
    ''' Devuelve una lista con los montos sospechosos de ms. '''
    res = []
    for m in ms:
        if es_sospechoso(m):
            res.append(m)
    return res

def suma_de_sospechosos(ms):
    ''' Devuelve la suma de los montos sospechosos de ms. '''
    res = 0
    sospechosos = filtrar_sospechosos(ms)
    for m in sospechosos:
        res = res + m
    return res

############################## Función auxiliar ##############################

def ultimo_digito_distinto_de_cero(m):
    ''' Devuelve el último dígito de m distinto de cero. '''
    m_str = str(m)
    i = len(m_str) - 1
    while i > 0 and m_str[i] == '0':
        i = i-1
    return int(m_str[i])
