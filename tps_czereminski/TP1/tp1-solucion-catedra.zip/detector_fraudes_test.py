import unittest

from detector_fraudes import multiplo_de_mil, suma_de_digitos_menor_que_diez, \
                   extremos_iguales, es_sospechoso, filtrar_sospechosos, \
                   suma_de_sospechosos

class TestDetectorFraudes(unittest.TestCase):

    def test_multiplo_de_mil_positivos(self):
        self.assertTrue(multiplo_de_mil(1000))
        self.assertTrue(multiplo_de_mil(5000))
        self.assertTrue(multiplo_de_mil(999000))

    def test_multiplo_de_mil_negativos(self):
        self.assertFalse(multiplo_de_mil(1234))
        self.assertFalse(multiplo_de_mil(999))
        self.assertFalse(multiplo_de_mil(1001))
        self.assertFalse(multiplo_de_mil(1))

    def test_suma_de_digitos_menor_que_diez_positivos(self):
        self.assertTrue(suma_de_digitos_menor_que_diez(1000))  # 1+0+0+0 = 1
        self.assertTrue(suma_de_digitos_menor_que_diez(123))   # 1+2+3 = 6
        self.assertTrue(suma_de_digitos_menor_que_diez(10))  # 1+0 = 10
        self.assertTrue(suma_de_digitos_menor_que_diez(9))     # 9

    def test_suma_de_digitos_menor_que_diez_negativos(self):
        self.assertFalse(suma_de_digitos_menor_que_diez(999))  # 9+9+9 = 27
        self.assertFalse(suma_de_digitos_menor_que_diez(55))  # 5+5 = 10

    def test_extremos_iguales_positivos(self):
        self.assertTrue(extremos_iguales(11000000))   # 1 y 1
        self.assertTrue(extremos_iguales(700700))   # 7 y 7
        self.assertTrue(extremos_iguales(10001))  # 1 y 1
        self.assertTrue(extremos_iguales(7000))   # 7 y 7
        self.assertTrue(extremos_iguales(1231))   # 1 y 1

    def test_extremos_iguales_negativos(self):
        self.assertFalse(extremos_iguales(12000120))  # 1 y 2
        self.assertFalse(extremos_iguales(1234))  # 1 y 4
        self.assertFalse(extremos_iguales(1200))  # 1 y 2

    def test_es_sospechoso_positivos(self):
        self.assertTrue(es_sospechoso(1000))  # cumple las tres condiciones
        self.assertTrue(es_sospechoso(3000))  # cumple las tres condiciones

    def test_es_sospechoso_negativos(self):
        self.assertFalse(es_sospechoso(1001)) # no cumple múltiplo de 1000
        self.assertFalse(es_sospechoso(99000)) # no cumple suma < 10
        self.assertFalse(es_sospechoso(1003000)) # no cumple extremos iguales
        self.assertFalse(es_sospechoso(1234)) # no cumple ninguna

    def test_filtrar_sospechosos_longitud(self):
        montos = [1000, 1001, 1234, 3000, 99000, 1003000]
        resultado = filtrar_sospechosos(montos)
        self.assertEqual(len(resultado),2)


    def test_filtrar_sospechosos_pertenencia_positiva(self):
        montos = [1000, 1001, 1234, 3000, 99000, 1003000]
        resultado = filtrar_sospechosos(montos)
        self.assertIn(1000, resultado)
        self.assertIn(3000, resultado)

    def test_filtrar_sospechosos_pertenencia_negativa(self):
        montos = [1000, 1001, 1234, 3000, 99000, 1003000]
        resultado = filtrar_sospechosos(montos)
        self.assertNotIn(1001, resultado)
        self.assertNotIn(1234, resultado)
        self.assertNotIn(999, resultado)

    def test_suma_de_sospechosos_suma_0(self):
        ms = []
        self.assertEqual(suma_de_sospechosos(ms), 0)
        ms = [1001, 1234, 100010]
        self.assertEqual(suma_de_sospechosos(ms), 0)

    def test_suma_de_sospechosos_suma_mayor_que_cero(self):
        ms = [1000, 1001, 1234, 3000, 99000, 1003000]
        self.assertEqual(suma_de_sospechosos(ms), 4000)
        ms = [1000, 2000, 1001000]
        self.assertEqual(suma_de_sospechosos(ms), 1004000)

unittest.main()
