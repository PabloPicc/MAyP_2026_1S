import requests
import matplotlib.pyplot as plt
from datetime import datetime

def obtener_datos_cripto(codigo_cripto, dias):
    '''
    Consulta la API de CoinGecko para obtener la población total de un país entre dos años.
    Devuelve una tupla (fechas, poblaciones) como dos listas sincronizadas
    '''
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass

def graficar_cripto(fechas, cotizaciones):
    ''' Grafica las cotizaciones de la cripto en las fechas indicadas. '''
    # BORRAR LA SIGUIENTE LÍNEA Y COMPLETAR
    pass

def solicitar_cripto():
    '''
    Le solicita al usuario que selecciones el país y devuelve su código.
    '''
    print()
    print('Criptomonedas')
    print('--------')
    print('  1. Bitcoin')
    print('  2. Ethereum')
    print('  3. Tether')
    print('  4. Solana')
    num_elegido = input('Seleccione una criptomoneda: ').upper().strip()
    if not num_elegido in {'1','2','3','4'}:
        input('Opción inválida. Presione ENTER para continuar')
        return solicitar_cripto()
    else:
        criptos = dict()
        criptos['1'] = 'bitcoin'
        criptos['2'] = 'ethereum'
        criptos['3'] = 'tether'
        criptos['4'] = 'solana'
        return criptos[num_elegido]

def solicitar_cantidad_dias():
    '''
    Le solicita al usuario que la cantidad de días a graficar.
    '''
    dias = int(input('\nIngrese la cantidad de días hacia atrás: ').strip())
    return dias


############# CUERPO PRINCIPAL DEL PROGRAMA #############
codigo_cripto = solicitar_cripto()
dias = solicitar_cantidad_dias()
datos = obtener_datos_cripto(codigo_cripto, dias)
fechas = datos[0]
cotizaciones = datos[1]
graficar_cripto(fechas, cotizaciones)
