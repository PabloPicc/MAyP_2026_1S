import networkx as nx
import matplotlib.pyplot as plt

## ---------------------------------------------------------
## EJERCICIO 1: Red de Amigos (Grafo Simple)
## ---------------------------------------------------------
## Considere un archivo amigos.csv donde 
## cada fila indica una relación de amistad entre dos personas

## 1. Construir un grafo no dirigido G a partir del archivo amigos.csv.
## 2. Dibujar el grafo mostrando el nombre de cada persona.
## 3. Calcular el grado de cada nodo.
## 4. Determinar cuántas componentes conexas tiene la red y listar sus nodos.


## ---------------------------------------------------------
## EJERCICIO 2: Rutas Urbanas (Grafo Ponderado)
## ---------------------------------------------------------
## Considere el archivo rutas_urbanas.csv con formato (Origen, Destino, Tiempo)
## 1. Crear un grafo ponderado G leyendo el archivo rutas_urbanas.csv.
## 2. Dibujar el grafo mostrando los tiempos de viaje sobre las aristas.
## 3. Para cada nodo, calcular:
##  -   cantidad de vecinos,
##  -   suma total de tiempos de las rutas que lo conectan.
## 4. Determinar cuál es el nodo mejor conectado (el de menor suma de tiempos).


## ---------------------------------------------------------
## EJERCICIO 3: Red de Colaboraciones (Conexidad y Centralidad)
## ---------------------------------------------------------
## Se tiene un archivo colaboraciones.csv que registra pares 
## de personas que trabajaron juntas en un proyecto
## 1. Crear el grafo G desde el archivo.
## 2. Verificar si la red es conexa.
## 3. Calcular qué nodo tiene el mayor grado.

