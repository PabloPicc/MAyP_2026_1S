# ==============================================================
# PRÁCTICA: Introducción a Pandas (Series + DataFrames)
# ==============================================================

import pandas as pd

# ==============================================================
# PARTE 1 - INTRO
# ==============================================================

# 1. Crear una Series simple con los siguientes datos e índices
datos = [10, 20, 30, 40]
indices = ['a', 'b', 'c', 'd'] 

# COMPLETAR

# 2. Imprimir la Series.
print("--- Parte 1: Ejercicio 2 ---")
# COMPLETAR

# 3. Mostrar el valor máximo y el promedio.
print('\n--- Parte 1: Ejercicio 3 ---')
# print('Valor máximo:', # COMPLETAR )
# print('Media:', # COMPLETAR )

# 4. Crear un DataFrame con las siguientes columnas y valores (utilizar diccionario)
# - Columna 'Ejercicio' con valores ['Squat', 'Dead Lift', 'Bench Press', 'Hip Thrust']
# - Columna 'RM' con valores [102.5, 130, 60, 250]

# COMPLETAR

# 5. Imprimir el DataFrame.
print('\n--- Parte 1: Ejercicio 5 ---')

# COMPLETAR

# 6. Crear una Series pesos_rm a partir del diccionario del punto anterior, donde los
# índices sean los nombres de los ejercicios y los valores sean los RM
print("\n--- Parte 1: Ejercicio 6 ---")
pesos_rm = None # COMPLETAR


# 7. Mostrar el RM de Dead Lift, usando acceso por etiqueta
print("\n--- Parte 1: Ejercicio 7 ---")
# COMPLETAR


# 8. Mostrar los RM de Squat y Hip Thrust usando acceso por lista de etiquetas.
print("\n--- Parte 1: Ejercicio 8 ---")
# COMPLETAR


# ==============================================================
# PARTE 2 - TRABAJAMOS CON student_exam_scores.csv
# ==============================================================
print("\n" + "="*50 + "\n")

# 1. Cargar el archivo 'student_exam_scores.csv' en un DataFrame llamado df.
# COMPLETAR

# 2. Mostrar las primeras filas (por defecto)
print("--- Parte 2: Ejercicio 2 (Primeras filas) ---")
# COMPLETAR

# 3. Mostrar las últimas 8 filas
print("\n--- Parte 2: Ejercicio 3 (Últimas 8 filas) ---")
# COMPLETAR


# 4. Mostrar la cantidad de registros
print("\n--- Parte 2: Ejercicio 4 (Cantidad de registros) ---")
# COMPLETAR


# 5. Crear una Series "horas_estudio" con las horas de estudio de los primeros 15 estudiantes.
print('\n--- Parte 2: Ejercicio 5 (Series de horas de estudio) ---')
horas_estudio = None # COMPLETAR

# 6. Calcular la suma total de horas de estudio de la Series "horas_estudio"
print("\n--- Parte 2: Ejercicio 6 (Suma de horas) ---")
# COMPLETAR


# 7. Ordenar la Series "horas_estudio" de forma descendente
print("\n--- Parte 2: Ejercicio 7 (Series ordenada) ---")
# COMPLETAR


# 8. Calcular el promedio y el valor máximo de la Series "horas_estudio".
print('\n--- Parte 2: Ejercicio 8 (Promedio y máximo) ---')
# COMPLETAR


# 9. Crear una Series con los elementos de la columna 'exam_score'
print("\n--- Parte 2: Ejercicio 9 (Series exam_score) ---")
# COMPLETAR


# 10. Crear un nuevo dataframe (df2) con los datos de las filas 3, 4 y 5 y columnas 'sleep_hours' y 'exam_score'.
print("\n--- Parte 2: Ejercicio 10 (Nuevo DataFrame df2) ---")
# COMPLETAR


# 11. Mostrar las universidades del campo 'university', sin repeticiones
print("\n--- Parte 2: Ejercicio 11 (Universidades únicas) ---")
# COMPLETAR


# 12. Mostrar las columnas 'student_id', 'attendance_percent' y 'previous_scores' del datframe df.
print("\n--- Parte 2: Ejercicio 12 (Selección de columnas) ---")
# COMPLETAR

# 13. Crear un nuevo dataframe (df3) con los datos de la fila 3.
print("\n--- Parte 2: Ejercicio 13 (Selección de una fila) ---")
# COMPLETAR


# 14. Seleccionar por etiqueta usando loc, primeros estudiantes de la unviersidad 'UT Austin'.
print("\n--- Parte 2: Ejercicio 14 (Selección con .loc) ---")
# COMPLETAR


# 15. Ordenar df por la columna exam_score en orden descendente y guardar el resultado en un DataFrame df_sorted
print("\n--- Parte 2: Ejercicio 15 (DataFrame ordenado) ---")
# COMPLETAR


# 16. Mostrar al student_id con la menor cantidad de horas de sueño
print("\n--- Parte 2: Ejercicio 16 (Estudiante con menos sueño) ---")
# COMPLETAR


# 17. Mostrar al student_id con la mayor cantidad de hours_studied y su universidad
print("\n--- Parte 2: Ejercicio 17 (Estudiante con más estudio) ---")
# COMPLETAR

# ==============================================================
# FIN 
# ==============================================================