import matplotlib.pyplot as plt
import numpy as np

temp_lunes = list(np.random.randint(10, 20, 24))
temp_martes = list(np.random.randint(10, 20, 24))
temp_miercoles = list(np.random.randint(10, 20, 24))
temp_jueves = list(np.random.randint(10, 20, 24))
temp_viernes = list(np.random.randint(10, 20, 24))
temp_sabado = list(np.random.randint(15, 20, 24))
temp_domingo = list(np.random.randint(15, 20, 24))

dias = ["Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo"]