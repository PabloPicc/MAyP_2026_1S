# Prática 09: Análisis de campañas digitales con pandas 
# Dataset: Campañas Digitales

import pandas as pd

# Cargar el dataset
df = pd.read_csv("data_p09.csv")

#-------------------------------- FILTROS ----------------------------------

# 1. Filtrar las filas donde la inversión (investment) sea mayor a 1000
print(# COMPLETAR)

# 2. Filtrar las filas donde hubo al menos 1 unidad vendida (unitsSold > 0)
print(# COMPLETAR)

# 3. Filtrar campañas con más de 1000 impresiones y más de 50 clics
print(# COMPLETAR)

# 4. Filtrar las filas donde el merchant sea 'Jinim' o 'Eurohogar Parrillas'
print(# COMPLETAR)

# 5. Filtrar campañas donde las ventas directas superan a las indirectas
print(# COMPLETAR)


#-------------------------------- AGRUPACIONES ------------------------------

# 6. Agrupar por tipo de campaña y calcular el promedio de inversión
print(# COMPLETAR)

# 7. Agrupar por país y calcular inversión total y ventas totales
print(# COMPLETAR) 

# 8. Agrupar por merchant y calcular cantidad de campañas distintas
print(# COMPLETAR)

# 9. Agrupar por plataforma y calcular maximo número de unidades vendidas
print(# COMPLETAR)

# 10. Agrupar por merchant y obtener el mínimo y máximo de ventas por publicidad (ads_sales)
print(# COMPLETAR)
