import csv


class Pasajero:
    def __init__(self, pid, edad, cuanto_pago, clase, sobrevivio):
        self.pid = pid
        self.edad = edad
        self.cuanto_pago = cuanto_pago
        self.clase = clase
        self.sobrevivio = sobrevivio

def leer_pasajeros(filepath):
    """
    Lee un archivo CSV con datos de pasajeros y devuelve una lista de objetos Pasajero.
    """
    f = open(filepath)
    
    # COMPLETAR

    f.close()

    return pasajeros

def escritura_supervivientes(pasajeros, nombre_archivo):
    """
    Recibe una lista de objetos Pasajero y escribe un nuevo archivo CSV
    solo con los datos de aquellos que sobrevivieron.
    """
    f = open(nombre_archivo, 'w', newline='')
    
    #  COMPLETAR

    f.close()


# 1. Definimos el nombre del archivo de entrada.
archivo_titanic = 'titanic_passengers.csv'

# 2. Llamamos a la primera funcón para leer los datos
lista_pasajeros = leer_pasajeros(archivo_titanic)
print("Se leyeron " + str(len(lista_pasajeros)) + " pasajeros en total.")

# Imprimimos los primeros 3 pasajeros para ver si los objetos se crearon correctamente.
if len(lista_pasajeros) > 0:
    # Verificación extra: accedemos a un atributo de un pasajero específico.
    primer_pasajero = lista_pasajeros[0]
    print(f"El primer pasajero (ID: {primer_pasajero.pid}) pagó: USD{primer_pasajero.cuanto_pago}")
    segundo_pasajero = lista_pasajeros[1]
    print(f"El segundo pasajero (ID: {segundo_pasajero.pid}) pagó: USD{segundo_pasajero.cuanto_pago} y tiene {segundo_pasajero.edad} años")

# 3. Definimos el nombre del archivo de salida.
archivo_salida = 'supervivientes.csv'

# 4. Llamamos a la segunda función para escribir el nuevo archivo.
escritura_supervivientes(lista_pasajeros, archivo_salida)


# --------------------------------------------------------------------
# Ejercicio Extra: Archivos.txt

def veintiuno(s):
    puntajes = {"m": 2, "M": 3, "l": 2, "L": 3}
    manu = 0
    luifa = 0

    for c in s:
        if c not in puntajes:
            return "El string contiene caracteres incorrectos"
        
        puntos = puntajes[c]
        if c in "mM":
            manu += puntos
            if manu > 21:
                manu = 15
            if manu == 21:
                return "Ganó Manu"
        else:
            luifa += puntos
            if luifa > 21:
                luifa = 15
            if luifa == 21:
                return "Ganó Luifa"


# Se le pide que en base a la función anterior, se programe una función que nuevamente reciba como parámetro 
# el string que representa la secuencia del juego y que escriba en un archivo '.txt' la secuencia de tiros del ganador.
# Debe estar en el siguiente formato:
# Doble
# Triple
# Triple
# .
# .
# .
# etc.
# Notar que debe ser solo la secuencia de tiros que lo llevó a ganar, no todo los tiros presentes en el string.

def secuencia_ganador(s):
    resultado = veintiuno(s)
    
    #  COMPLETAR
    pass

# Defino una función para leer el archivo de la función anterior 
def leer_secuencia_ganador(nombre_archivo):
    with open(nombre_archivo, 'r') as archivo:
        contenido = archivo.read().strip()
    return contenido


# Ejemplo de aplicación de funciones veintuno(s) y secuencia_ganador(s)

s_1 = 'MMMlLLLLmMlLmMlLm' # Ganó Luifa
s_2 = 'MMMlLLLLmMlLmMLLm' # Ganó Manu
s_3 = 'lLllLmmMlLLlLL' # Ganó Luifa
print(veintiuno(s_1))
print(veintiuno(s_2))
print(veintiuno(s_3))
secuencia_ganador(s_1)
secuencia_ganador(s_2)

nombre_archivo = 'secuencia_Luifa.txt'
print(leer_secuencia_ganador(nombre_archivo)) # imprime el contenido del archivo secuencia_Luifa