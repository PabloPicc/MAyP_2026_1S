import unittest
from maximo_profit import maximo_profit_accion

class MaximoProfitTest(unittest.TestCase):

    def test_maximo_profit(self):
        self.assertEqual(maximo_profit_accion([]), 0)
        self.assertEqual(maximo_profit_accion([7, 1, 5, 6, 3]), 5)
        #Armar casos de test aqui


if __name__ == '__main__':
    unittest.main()
