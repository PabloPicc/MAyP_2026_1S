class Inversor:
    def __init__(self, nombre, apellido):
        self.nombre = nombre
        self.apellido = apellido
        self.cartera = dict()

    def agregar_inversion(self, cod_accion, cantidad):
        if cod_accion in self.cartera:
            self.cartera[cod_accion] += cantidad
        else:
            self.cartera[cod_accion] = cantidad

    def vender_inversion(self, cod_accion, cantidad):
        self.cartera[cod_accion] -= cantidad

    def cuanto_invirtio(self, cod_accion):
        if cod_accion not in self.cartera:
            return 0
        else:
            return self.cartera[cod_accion]
        
    def inversiones_con_min_cantidad(self, cantidad):
        acc_min_cant = set()
        for accion in self.cartera:
            if self.cartera[accion] >= cantidad:
                acc_min_cant.add(accion)
        return acc_min_cant