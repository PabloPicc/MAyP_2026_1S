# DISCLAIMER: Esta no es la manera mas eficiente de resolver el problema,
# pero es efectiva para introducir un bug que deben encontrar y resolver :)

def maximo_profit_accion(precios_accion):
    '''
    Dada la lista precios_accion, donde precios_accion[i] indica el precio de la accion en el dia i,
    devuelve el maximo profit posible, comprando en un determinado dia y vendiendo en otro dia futuro.
    '''
    maximo_profit = 0
    for i in range(len(precios_accion)-1):
        for j in range(i, len(precios_accion)-1):
            diferencia = precios_accion[j] - precios_accion[i]
            maximo_profit = max(maximo_profit, diferencia)
    return maximo_profit
