import unittest
from inversor import Inversor

class InversorTest(unittest.TestCase):

    def test_init(self):
        '''Testea el constructor de la clase Inversor.'''
        messi = Inversor('Lionel', 'Messi')
        

    def test_agregar_accion(self):
        '''Testea el metodo agregar_inversion.'''
        pass 

    def test_cuanto_invirtio(self):
        '''Testea el metodo cuanto_invirtio.'''
        pass

    def test_vender_accion(self):
        '''Testea el metodo vender_inversion.'''
        pass

    def test_min_cantidad(self):
        '''Testea el metodo inversiones_con_min_cantidad.'''
        pass

    def test_total_acciones(self):
        '''Testea el metodo total_acciones.'''
        pass

    def test_posiciones(self):
        '''Testea el metodo posiciones.'''
        pass
    
    def test_comparacion(self):
        '''Testea los metodos de comparacion.'''
        messi = Inversor('Lionel', 'Messi')
        cristiano = Inversor('Cristiano', 'Ronaldo')
        

    def test_fusionar_carteras(self):
        '''Testea el metodo fusionar_carteras.'''

        

if __name__ == '__main__':
    unittest.main()
